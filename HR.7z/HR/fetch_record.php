<html>
<head>
    <style>
        tr,td,th{
            padding: 10px;
        }
    </style>
</head>
</html>

<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'config/conn.php';


if(isset($_POST['rowid'])) {
   $id = $_POST['rowid'];
    $sql_Aproov_a = "select * from manpower_request where id='$id'";
    $qq_aproov_a = mysqli_query($conn, $sql_Aproov_a);
//    echo mysqli_num_rows($qq_aproov_a);
    echo "<table class='table-hover'>";
    while ($rr_aproove_a = mysqli_fetch_assoc($qq_aproov_a)) {
       $id = $rr_aproove_a['id'];
        echo "
                                                  <tr><th>Request Id</th><td>" . $rr_aproove_a['request_id'] . "</td></tr>
                                                  <tr class='table-success'><th>Designation</th><td>" . $rr_aproove_a['designation'] . "</td></tr>
                                                  <tr><th>Number Of Employee</th><td>" . $rr_aproove_a['no_of_employees'] . "</td></tr>
                                                  <tr class='table-success'><th>Budget Provision</th><td>" . $rr_aproove_a['budget_provision'] . "</td></tr>
                                                  <tr><th>Available Carder</th><td>" . $rr_aproove_a['available_carder'] . "</td></tr>
                                                  <tr class='table-success'><th>Plant Code</th><td>" . $rr_aproove_a['plant_code'] . "</td></tr>
                                                  <tr><th>comments</th><td>" . $rr_aproove_a['comments'] . "</td></tr>

                                                  <tr>";

    }
    echo "</table>";
}
?>
