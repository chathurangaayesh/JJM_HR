<?php
//
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);


session_start();
include 'config/conn.php';
include_once ("/../class/setting.php");
$setting = new setting();
//include_once ("class/notifications.php");

if(!isset($_SESSION['full_name'])) {

    header('location:login.php');
}else{
    $now = time(); // Checking the time now when home page starts.

    if ($now > $_SESSION['expire']) {
        session_destroy();
        header('location:login.php');

    }else{
        $fullname=$_SESSION['full_name'];
        $log_username=$_SESSION["user_name"];
        $log_user_id=$_SESSION["log_id"];
        $profile_pic=$_SESSION["profile_pic"];
    }
}


?>
