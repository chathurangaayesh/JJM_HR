<?php


include_once('config/doc_head.php');

include 'config/conn.php';

if(isset($_GET['token_del']))
{
    $suscceess='';
    $encoded=$_GET['token_del'];
    $decoded = base64_decode($encoded);
    $sql_del = "DELETE FROM user_roles WHERE id='$decoded'";

    if (mysqli_query($conn, $sql_del)) {
        $suscceess=3;
    }else{
        $suscceess=0;
    }

}

    if(isset($_POST['add'])){
        $suscceess='';
        $role_code = mysqli_real_escape_string($conn, $_POST['role_code']);
        $role_name = mysqli_real_escape_string($conn, $_POST['role_name']);
        $privilage = mysqli_real_escape_string($conn, $_POST['privilage']);
        $log_username=$_SESSION["user_name"];
        $CREATE_USER=$_SESSION["user_name"];

        $sql="INSERT INTO user_roles (role_code , description  ,create_date , create_user ) VALUES
                                      ('$role_code','$role_name',CURRENT_TIMESTAMP ,'$CREATE_USER') ";


        if (mysqli_query($conn, $sql)) {
            $suscceess=1;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            $suscceess=0;
        }
    }
if(isset($_POST['edit'])){
    $suscceess='';
    $role_code = mysqli_real_escape_string($conn, $_POST['role_code']);
    $role_name = mysqli_real_escape_string($conn, $_POST['role_name']);
    $privilage = mysqli_real_escape_string($conn, $_POST['privilage']);
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $CREATE_USER=$_SESSION["user_name"];

    $sql_2="UPDATE user_roles SET role_code = '$role_code', description= '$role_name'
              WHERE id = $id;";


    if (mysqli_query($conn, $sql_2)) {
        $suscceess=2;
    } else {
        echo "Error: " . $sql_2 . "<br>" . mysqli_error($conn);
        $suscceess=0;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JJM HR -Registation User</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

  <!-- Custom styles for this template-->
  <link href="css/HR-admin-2.css" rel="stylesheet">
    <style>
        /*.tab-pane {*/

            /*background-color: #fff;*/
            /*border: 1px solid #ccc;*/
            /*border-top: none;*/
            /*border-radius: 0 0 4px 4px;*/

        /*}*/
        form{
            padding-top: 20px;
            padding-left: 200px;

        }
        form td{
            padding: 1em 1.2em;
        }
        #right {
            margin-left: 96%;
            float: right;
            width: 30px;
            height: 20px;
            text-align: center;
        }
        #right a {
            float: right;
            color: #FFFFFF;
            text-decoration: none;
            display: inline-block;
        }
        #right a:hover {
            font-weight: 500;
        }

    </style>
    <script>
        //          ===================================== message box close button =======================================
        function Hide(HideID)
        {
            HideID.style.display = "none";
        }

    </script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-users-cog"></i>
        </div>
        <div class="sidebar-brand-text mx-3">JJM HR  <sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Interface
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item active">
        <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Masters</span>
        </a>
        <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Masters Table:</h6>

              <a class="collapse-item " href="Department.php">Department</a>
              <a class="collapse-item " href="cluster.php">Cluster</a>
              <a class="collapse-item " href="Company.php">Company</a>
              <a class="collapse-item active" href="Role.php">Role </a>
          </div>
        </div>
      </li>



      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Process
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header"> Screens:</h6>
              <a class="collapse-item " href="user_mgt.php">User Registation</a>
              <a class="collapse-item " href="manpuwer_request-old.php">Manpower Request</a>
              <a class="collapse-item" href="Request_action.php">Requests Action</a>

<!--            <a class="collapse-item" href="register.html">Register</a>-->
<!--            <a class="collapse-item" href="forgot-password.html">Forgot Password</a>-->
<!--            <div class="collapse-divider"></div>-->
<!--            <h6 class="collapse-header">Other Pages:</h6>-->
<!--            <a class="collapse-item" href="404.html">404 Page</a>-->
<!--            <a class="collapse-item" href="blank.html">Blank Page</a>-->
          </div>
        </div>
      </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-address-card" aria-hidden="true"></i>
                <span>New</span>
            </a>
            <div id="collapse" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">New Employee:</h6>
                    <a class="collapse-item " href="approved_request.php">Approved Request</a>

                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <span>Notification</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">More:</h6>
                    <a class="collapse-item " href="notification.php">More Notifications</a>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="approved_applicant_cv.php">Applicants</a>';
                    }?>

                    <?php if(($setting->roleValQyesry($log_username))=='HROfficer') {
                        echo '<a class="collapse-item " href="calling_interview.php">Calling For interview</a>';
                        //echo $log_username ;
                    }?>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="inteview_shedule_approve.php">Sheduled Interview</a>';
                    }?>
                </div>
            </div>
        </li>
      <!-- Nav Item - Charts -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="charts.html">-->
<!--          <i class="fas fa-fw fa-chart-area"></i>-->
<!--          <span>Charts</span></a>-->
<!--      </li>-->
<!---->
<!--      <!-- Nav Item - Tables -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="tables.html">-->
<!--          <i class="fas fa-fw fa-table"></i>-->
<!--          <span>Tables</span></a>-->
<!--      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">

                </script>
                <script type="text/javascript">
                var auto_refresh = setInterval(
                    function ()
                    {
                        $('#load_tweets').load('notification_button.php?id=<?php echo $log_username; ?>').fadeIn("slow");
                    }, 10000); // refresh every 10000 milliseconds





                </script>

                <div id="load_tweets"><?php
                    include_once("notification_button.php");
                    ?>
                </div>
            </li>



            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $fullname;?></span>
                  <img class="img-profile rounded-circle" src="img/profile/<?php echo $profile_pic;?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                  <a class="dropdown-item" href="user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
<!--            //================================================================================Succsess Add Msessage==========================================-->
          <?php if(isset($suscceess)){
              if($suscceess==1 ||$suscceess ==2 || $suscceess=3){
          ?>


            <div class="col-lg-12 mb-4" id="Bar">
                <div class="card bg-success text-white shadow">
                    <div id="right">
                        <a href="#" onclick="Hide(Bar);">X</a>
                    </div>
                    <div class="card-body">
                        Success
                        <?php
                        if($suscceess==1){
                            echo "<div class='text-white-50 small'>New Role Entred</div>";
                        }elseif($suscceess==2){
                            echo "<div class='text-white-50 small'>Edit role</div>";
                        }elseif($suscceess==3){
                            echo "<div class='text-white-50 small'>Delete Company Success</div>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
              }
          }
          ?>
            <!--            //================================================================================Error Add Msessage==========================================-->
            <?php if(isset($suscceess)){
                if($suscceess==0){
                    ?>


                    <div class="col-lg-12 mb-4" id="Bar">
                        <div class="card bg-danger text-white shadow">
                            <div id="right">
                                <a href="#" onclick="Hide(Bar);">X</a>
                            </div>
                            <div class="card-body">
                                Error
                                <div class="text-white-50 small">Duplicate Data ! Cluster olredy Exist</div>
                            </div>
                        </div>
                    </div>
                <?php
                }
            }
            ?>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Registation</h1>
          </div>

          <div class="row">
              <div class="col-lg-12">
              <nav>
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                      <?php
                      if(isset($_GET['token'])){
                          ?>

                          <a class="nav-item nav-link " id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="false">Roles</a>
                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">New Role</a>
                          <a class="nav-item nav-link active" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="true">Edit Role</a>
                      <?php
                      }else{
                      ?>
                          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Roles</a>
                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">New Role</a>


                      <?php }
                      ?>

                  </div>
              </nav>
                  </div>
              <div class="col-lg-12">


              <div class="tab-content" id="nav-tabContent">

                  <?php
                  if(isset($_GET['token'])){

                  echo "<div class='tab-pane fade show' id='nav-home' role='tabpanel' aria-labelledby='nav-home-tab'>";

                      }else{
                      echo "<div class='tab-pane fade show active' id='nav-home' role='tabpanel' aria-labelledby='nav-home-tab'>";
                       }
                      ?>




                              <div class="container-fluid">



                                  <div class="card-body">
                                      <div class="table-responsive">
                                          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                              <thead>
                                              <tr>
                                                  <th>Role Code</th>
                                                  <th>description</th>

                                                  <th>Action</th>

                                              </tr>
                                              </thead>
                                              <tfoot>
                                              <tr>
                                                  <th>Role Code</th>
                                                  <th>description</th>

                                                  <th>Action</th>
                                              </tr>
                                              </tfoot>
                                              <tbody>

                                              <?php
                                              $sql_1="SELECT * FROM `user_roles` ";
                                              $QQ=mysqli_query($conn, $sql_1);

                                              while ($RR=mysqli_fetch_assoc($QQ)){
                                                  $id=$RR['id'];
                                                  $string  = $id;
                                                  $encoded = base64_encode($string);
                                                  echo "<tr>
                                                  <td>".$RR['role_code']."</td>
                                                  <td>".$RR['description']."</td>
                                                  <td>";

                                                  echo '<a class="btn btn-default btn-flat" href="'.$script_name.'?token='.$id.'"  data-toggle="tooltip" ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
                                                  echo '<a class="btn btn-default btn-flat delete" href="'.$script_name.'?token_del='.$encoded.'" data-toggle="tooltip" data-confirm="Are you sure to delete this item?"><i class="fa fa-trash" aria-hidden="true"></i></a>';


                                          echo"    </td></tr>";

                                              }
                                              ?>



                                              </tbody>
                                          </table>
                                      </div>
                                  </div>



                              </div>


                      </div>

                  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">

                      <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                      <table>
                          <tr>
                              <td class="label"><div class="text-right">Role Code :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" class="form-control "  name="role_code"  required  placeholder="Role Code" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Role Name :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" class="form-control " name="role_name" required placeholder="Role Name" >
                                  </div>
                              </td>
                          </tr>


                          <tr>
                              <td><div class="text-right">Privilages :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" class="form-control " name="privilage" placeholder="Description..." >
                                  </div>
                              </td>
                          </tr>
                            <tr>
                              <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                      <span class="text">Reset</span>
                                  </button>
                              </td>
                              <td>
                                  <div class="input-group">

                                      <button TYPE="submit" name="add" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                          <span class="text">Add</span>
                                      </button>

                                  </div>
                              </td>
                          </tr>


                      </table>

                  </form>
                  </div>

<!--                 ==================================================================== edite ======================= ==-->
                  <?php
                  if(isset($_GET['token'])) {

                      ?>

                      <div class="tab-pane fade show active" id="nav-contact" role="tabpanel"
                           aria-labelledby="nav-contact-tab">

                          <form
                              class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search"
                              action="<?= $_SERVER['PHP_SELF']; ?>" method="POST">

                              <!--                          --><?php
                              $id = $_GET['token'];
                              $sql_2 = "SELECT * FROM `user_roles` where id=$id";
                              $QQ_2 = mysqli_query($conn, $sql_2);

                              while ($RR_2 = mysqli_fetch_assoc($QQ_2)) {
                                  $role_code = $RR_2['role_code'];
                                  $description = $RR_2['description'];
                              }
                              //
                              //
                              ?>
                              <table>
                                  <tr>
                                      <td class="label">
                                          <div class="text-right">Role Code :</div>
                                      </td>
                                      <td>
                                          <div class="input-group">
                                              <input type="text" class="form-control " name="role_code" value="<?php echo $role_code; ?>" required placeholder="Role Code">
                                              <input type="hidden"  name="id" value="<?php echo $id; ?>" >
                                          </div>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <div class="text-right">Role Name :</div>
                                      </td>
                                      <td>
                                          <div class="input-group">
                                              <input type="text" class="form-control " name="role_name"
                                                     value="<?php echo $description; ?>" required
                                                     placeholder="Role Name">
                                          </div>
                                      </td>
                                  </tr>


                                  <tr>
                                      <td>
                                          <div class="text-right">Privilages :</div>
                                      </td>
                                      <td>
                                          <div class="input-group">
                                              <input type="text" class="form-control " name="privilage"
                                                     placeholder="Description...">
                                          </div>
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <button TYPE="reset" class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                              <span class="text">Reset</span>
                                          </button>
                                      </td>
                                      <td>
                                          <div class="input-group">

                                              <button TYPE="submit" name="edit" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fa fa-pencil" aria-hidden="true"></i>
                                        </span>
                                                  <span class="text">Edit</span>
                                              </button>

                                          </div>
                                      </td>
                                  </tr>


                              </table>

                          </form>
                      </div>
                  <?php
                  }
                  ?>
              </div><!--<div class="col-lg-12">-->








                  </div>
              <!--==========================================================================-->

              <!--<div class="tab">-->

                  <!--<button class="links " onclick="openLang(event,'USERS')">USERS</button>-->
                  <!--<button class="links" onclick="openLang(event,'New User')">New User</button>-->

              <!--</div>-->
                  <!--</div>-->






</div>
            <!-- Pending Requests Card Example -->




        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php?token=lo1">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
      <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
      <script>
          $(function () {
              $("#USERS").css("display", "block");
              $("div.tab button:first-child" ).addClass(" active");
              $(".content").click(function () {

                  var links = document.getElementsByClassName("links");
                  for (i = 0; i < links.length; i++) {
                      links[i].className = links[i].className.replace("active", "");
                  }
              });
          });

          function openLang(e, lang) {
              var links = document.getElementsByClassName("links");
              var content = document.getElementsByClassName("content");
              for (i = 0; i < content.length; i++) {
                  content[i].style.display = "none";
              }
              for (i = 0; i < links.length; i++) {
                  links[i].className = links[i].className.replace(" active", "");
              }
              document.getElementById(lang).style.display = "block";
              document.getElementById(lang).style.opacity = "1";
              e.currentTarget.className += " active";
          }

      </script>
  <!--  ======================== delete  pop===========-->
  <script>
      $('.delete').on("click", function (e) {
          e.preventDefault();

          var choice = confirm($(this).attr('data-confirm'));

          if (choice) {
              window.location.href = $(this).attr('href');
          }
      });

  </script>

</body>

</html>
