<?php
include_once('config/doc_head.php');
include_once ("class/notifications.php");
$notifications = new notifications();
if(isset($_GET['token']))
{

    $encoded=$_GET['token'];
    $request_id = base64_decode($encoded);
    $_SESSION['request_id']=$request_id;

}else{
    if(isset($_POST['add'])){
        $cv_id=mysqli_real_escape_string($conn, $_POST['cv_id']);
        $in_date=mysqli_real_escape_string($conn, $_POST['in_date']);
        $in_time=mysqli_real_escape_string($conn, $_POST['in_time']);

        $time = date( "H:i:s", strtotime( $in_time ) );
         $sql="UPDATE aplicant_cv SET interview_date='$in_date' , interview_time='$time' ,interview_Address='' WHERE id='$cv_id'";


        $success_notify=$notifications->notify_interview($cv_id,$log_username,$in_date,$time);
        if (mysqli_query($conn, $sql)) {
            $suscceess=1;
            header('location:calling_interview.php?success=1');

        } else {
            Echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            $suscceess=0;
        }
    }else{
        header('location:calling_interview.php');
    }

}


?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JJM HR - Dashboard</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/HR-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        .bg-dashbord-image{
            background:url(img/login-img.jpg);
            background-position:center;
            width: auto;
            height:796px;
            background-repeat:no-repeat;
            background-size:  500px auto;
            text-align: center;
            padding-top: 40px;

        }.container-fluid{
                     background-color: #fff;
                     border: 1px solid #ccc;
                     border-top: none;
                     border-radius: 0 0 4px 4px;
                 }
        .form td{
          padding: 16px;
        }
    </style>
    <script type="text/javascript">
        var auto_refresh = setInterval(
            function ()
            {
                $('#mydiv').fadeOut('slow',$(this).load('index.php #mydiv',
                        function(){
                            $(this).fadeIn("slow");
                        })
                )
            }, 5000);
    </script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-users-cog"></i>
        </div>
        <div class="sidebar-brand-text mx-3">JJM HR <sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link active" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Marsters
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Masters</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Master Table:</h6>


              <a class="collapse-item " href="Department.php">Department</a>
              <a class="collapse-item " href="cluster.php">Cluster</a>
              <a class="collapse-item " href="Company.php">Company</a>
              <a class="collapse-item " href="Role.php">Role </a>
          </div>
        </div>
      </li>


      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Process
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Screens:</h6>
              <a class="collapse-item " href="user_mgt.php">User Registation</a>
              <a class="collapse-item " href="manpuwer_request.php">Manpower Request</a>
              <a class="collapse-item" href="Request_action.php">Requests Action</a>

          </div>
        </div>
      </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-address-card" aria-hidden="true"></i>
                <span>New</span>
            </a>
            <div id="collapse" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">New Employee:</h6>
                    <a class="collapse-item " href="approved_request.php">Approved Request</a>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="approved_applicant_cv.php">Applicants</a>';
                    }?>

                    <?php if(($setting->roleValQyesry($log_username))=='HROfficer') {
                        echo '<a class="collapse-item " href="calling_interview.php">Calling For interview</a>';
                        //echo $log_username ;
                    }?>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="inteview_shedule_approve.php">Sheduled Interview</a>';
                    }?>
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <span>Notification</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">More:</h6>
                    <a class="collapse-item " href="notification.php">More Notifications</a>

                </div>
            </div>
        </li>



<!--      <!-- Nav Item - Charts -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="charts.html">-->
<!--          <i class="fas fa-fw fa-chart-area"></i>-->
<!--          <span>Charts</span></a>-->
<!--      </li>-->
<!---->
<!--      <!-- Nav Item - Tables -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="tables.html">-->
<!--          <i class="fas fa-fw fa-table"></i>-->
<!--          <span>Tables</span></a>-->
<!--      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1" >


                </script>
                <script type="text/javascript">
                    var auto_refresh = setInterval(
                        function ()
                        {
                            $('#load_tweets').load('notification_button.php?id=<?php echo $log_username; ?>').fadeIn("slow");
                        }, 20000); // refresh every 10000 milliseconds





                </script>

                <div id="load_tweets"><?php
                    include_once("notification_button.php");
                    ?>
                </div>



            </li>


            <!-- Nav Item - Messages -->


            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-500 small"><?php echo $fullname;?></span>
                  <img class="img-profile rounded-circle" src="img/profile/<?php echo $profile_pic;?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Interview Arrangement</h1>
          </div>
          <!-- Begin Page Content -->
          <div class="conta iner-fluid" >
              <div class="card shadow mb-4">
              <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Shedule Interview</h6>
              </div>

                  <div class="card-body">
                      <div class="row">
                          <div class=" col-md-5"  style="float:left">
              <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                  <table class="form">
                      <tr>
                          <td class="label"><div class="text-right">Request ID :</div></td>
                          <td>
                              <div class="input-group">
                                  <input type="text" class="form-control " value="<?php echo $request_id;?>" readonly >
                                  <input type="hidden" class="form-control " value="<?php echo $request_id;?>" name="re_id" >
                              </div>
                          </td>
                      </tr>
                      <tr>
                          <td><div class="text-right">Select Applicant :</div></td>
                          <td>
                              <div class="input-group">
                                  <select class="browser-default custom-select" required="" name="cv_id">
                                      <option selected disabled>Select Applicant </option>
                                      <?php
                                      $sql_3="SELECT * FROM `aplicant_cv` where request_id='$request_id'";
                                      $QQ_2=mysqli_query($conn, $sql_3);

                                      while ($RR_2=mysqli_fetch_assoc($QQ_2)){
                                          echo "  <option  value='".$RR_2['id']."'>".$RR_2['name']."</option>";
                                          // echo $RR_2['cluster_code'];
                                          // echo $RR_2['cluster_name'];
                                          // echo "<option name='cluster_code' value="1">One</option>";
                                      }
                                      ?>

                                  </select>
                              </div>
                          </td>
                      </tr>


                      <tr>
                          <td><div class="text-right">Interview Date  :</div></td>
                          <td>
                              <div class="input-group">
                                  <input type="date" class="form-control " name="in_date"  >
                              </div>
                          </td>
                      </tr>
                      <tr>
                          <td><div class="text-right">Interview Time  :</div></td>
                          <td>
                              <div class="input-group">
                                  <input type="time" class="form-control " name="in_time"  >
                              </div>
                          </td>
                      </tr>
                      <tr>
                          <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                  <span class="text">Reset</span>
                              </button>
                          </td>
                          <td>
                              <div class="input-group">

                                  <button TYPE="submit" name="add" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                      <span class="text">Add</span>
                                  </button>

                              </div>
                          </td>
                      </tr>


                  </table>

              </form>

                        </div>
                        <div class="col-md-7 table-responsive"  >

                      <table class="table table-bordered">
                          <tr style="text-align: center"><th colspan="5">Sheduled CV s</th></tr>
                          <tr><th>Name</th>
                              <th>Email</th>
                              <th>Interview Date</th>
                              <th>Interview time</th>
                              <th>Approved Status</th>
                          </tr>




                          <?php
                          $request_id=$_SESSION['request_id'];
                          $sql="SELECT * FROM aplicant_cv WHERE request_id ='$request_id' and interview_date is not NULL and is_read='0' ";
                          $QQ=mysqli_query($conn, $sql);
                        if(mysqli_num_rows($QQ)>0){
                            while($RR=mysqli_fetch_assoc($QQ)){
                                $approve_in_status=$RR['approve_in_status'];
                                if($approve_in_status==0){
                                    $approve_status="Pending";
                                }elseif($approve_in_status==1){
                                    $approve_status="Approved";
                                }
                                $parth=$RR['cu_parth'];

                                echo "<tr><td><a href='applicant/CV/".$parth."' target='_blank' title='Click for View CV'>".$RR['name']."</a></td>

                                    <td>".$RR['email']."</td>
                                    <td>".$RR['interview_date']."</td>
                                    <td>".$RR['interview_time']."</td>
                                     <td>".$approve_status."</td></tr>";
                            }

                        }else{
                            echo "<tr style='text-align: center'><td colspan='4'> No data</td></tr>";
                        }

                          ?>
                      </table>

                        </div>
                  </div>
          </div>
          <!-- /.container-fluid -->




      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; JJM MIS 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php?token=lo1">Logout</a>
        </div>
      </div>
    </div>
  </div>


  <script>
      $(function () {
          $('[data-toggle="tooltip"]').tooltip()
      })
  </script>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>


</body>

</html>
