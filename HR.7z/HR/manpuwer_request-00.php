<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);





include 'config/conn.php';
session_start();
if(!isset($_SESSION['full_name'])) {

    header('location:login.php');
}else{
    $now = time(); // Checking the time now when home page starts.

        if ($now > $_SESSION['expire']) {
             session_destroy();
            header('location:login.php');

}else{
            $fullname=$_SESSION['full_name'];
        }
}


if(isset($_POST['add_new'])|| isset($_POST['add_re'])){
    $No_EMP=mysqli_real_escape_string($conn, $_POST['No_EMP']);
   echo $designation=mysqli_real_escape_string($conn, $_POST['designation']);
    $Budget_Pro=mysqli_real_escape_string($conn, $_POST['Budget_Pro']);
    $Available_No=mysqli_real_escape_string($conn, $_POST['Available_No']);

    echo $Comments=mysqli_real_escape_string($conn, $_POST['Comments']);

    if(isset($_POST['add_re'])){
        $epf_array=mysqli_real_escape_string($conn, $_POST['epf']);
        $name_array=mysqli_real_escape_string($conn, $_POST['name']);
    }

    print_r($epf_array);


  //  $sql="INSERT INTO department (dept_code , dept_name , description ,cluster_code,create_date , create_user ) VALUES ('$dept_code','$dept_name','$dept_desp','$cluster_code',CURRENT_TIMESTAMP ,'$CREATE_USER') ";


//    if (mysqli_query($conn, $sql)) {
//        $suscceess=1;
//
//    } else {
//        Echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//        $suscceess=0;
//    }
}




?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JJM HR - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
  <!-- Custom styles for this template-->
  <link href="css/HR-admin-2.css" rel="stylesheet">
    <style>
       . tainer-fluid{
           background-color: #fff;
           border: 1px solid #ccc;

       }
        .table-second{
            padding-top: 10px;
            align-items: center;
            width: 100%;
            margin-left:30%;

        }
        .table-head{
            align-items: center;
        }
        form td{
            padding: 1em 1.2em;
        }
        form{
            background-color: #fff;
            width: 100%;
        }
        .text-right{

            text-align: right;
        }.select{

           margin-left:50px;
                 }
         .select-type{
            display: inline-block;
             width:300px;
             margin:0 auto;

         }
        .input {
                margin-top: 2px;
        }

    </style>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-users-cog"></i>
        </div>
        <div class="sidebar-brand-text mx-3">JJM HR <sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Marsters
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>User Mgt</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Users:</h6>
              <a class="collapse-item " href="user_mgt.php">User Registation</a>
              <hr/>
              <a class="collapse-item " href="Department.php">Department</a>
              <a class="collapse-item " href="cluster.php">Cluster</a>
              <a class="collapse-item " href="Company.php">Company</a>
              <a class="collapse-item " href="Role.php">Role </a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">-->
<!--          <i class="fas fa-fw fa-wrench"></i>-->
<!--          <span>Utilities</span>-->
<!--        </a>-->
<!--        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">-->
<!--          <div class="bg-white py-2 collapse-inner rounded">-->
<!--            <h6 class="collapse-header">Custom Utilities:</h6>-->
<!--            <a class="collapse-item" href="utilities-color.html">Colors</a>-->
<!--            <a class="collapse-item" href="utilities-border.html">Borders</a>-->
<!--            <a class="collapse-item" href="utilities-animation.html">Animations</a>-->
<!--            <a class="collapse-item" href="utilities-other.html">Other</a>-->
<!--          </div>-->
<!--        </div>-->
<!--      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Process
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Screens:</h6>
            <a class="collapse-item active" href="manpuwer_request-00.php">Manpower Request</a>
            <a class="collapse-item" href="register.html">Register</a>
            <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Other Pages:</h6>
            <a class="collapse-item" href="404.html">404 Page</a>
            <a class="collapse-item" href="blank.html">Blank Page</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Charts -->
      <li class="nav-item">
        <a class="nav-link" href="charts.html">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>
      </li>

      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="tables.html">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">3+</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 12, 2019</div>
                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-warning">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 2, 2019</div>
                    Spending Alert: We've noticed unusually high spending for your account.
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
              </div>
            </li>

            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter">7</span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div>
                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/AU4VPcFN4LE/60x60" alt="">
                    <div class="status-indicator"></div>
                  </div>
                  <div>
                    <div class="text-truncate">I have the photos that you ordered last month, how would you like them sent to you?</div>
                    <div class="small text-gray-500">Jae Chun · 1d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/CS2uCrpNzJY/60x60" alt="">
                    <div class="status-indicator bg-warning"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Last month's report looks great, I am very happy with the progress so far, keep up the good work!</div>
                    <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</div>
                    <div class="small text-gray-500">Chicken the Dog · 2w</div>
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-500 small"><?php echo $fullname;?></span>
                <img class="img-profile rounded-circle" src="img/user.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->

       <div class="con tainer-fluid">

          <!-- Page Heading -->
           <div class="d-sm-flex align-items-center justify-content-between mb-4">
               <h1 class="h3 mb-0 text-gray-800"></h1>

           </div>



            <!-- Pie Chart -->


          <!-- Content Row -->
          <div class="row">

              <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                  <div align="center">
                      <h1 class="h3  text-gray-800" style="padding-top:10px ">Manpower Request Form</h1>
                      <hr/>
                      <hr/>
                  </div>
            <!-- Content Column -->
              <div class="col-lg-12 " align="center">

                  <table class="table-head">
                  <tr>
                      <td class="label"><div class="text-right">Plant :</div></td>
                      <td>
                          <div class="input-group">

                              <input type="text" class="form-control " name="plant" required=""   placeholder="Plant" >
                          </div>
                      </td>
                      <td class="label"><div class="text-right">Request Date (Befor) :</div></td>
                      <td>
                          <div class="input-group">

                              <input type="date" class="form-control " name="request_date" required=""   placeholder="Department Code..." >
                          </div>
                      </td>
                  </tr>
                  </table>
                  <hr/>


              </div>

                    <div class="col-lg-12 ">
                    <div  class="" >




                            <div class="form-group select-type" align="center">
                                <div class="text-right">
                                <label for="seeAnotherField">Request Type</label>
                                </div>
                                <div class="input-group">
                                <select class="form-control select" id="seeAnotherField">
                                    <option >Request type</option>
                                    <option value="replacement">Replacement</option>
                                    <option value="new">New</option>
                                </select>
                                    </div>
                            </div>
                                <hr/>

                            <div class="form-group table-second" id="otherFieldDiv" STYLE="margin-top: 10px">
                                <table>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                Designation :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="text" class="form-control " id="otherField"  name="designation"    placeholder="designation ..." >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                No.of Emp. Required :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="number" class="form-control " id="otherField"  name="No_EMP"    placeholder="No.of Emp. Required" >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                               Budget Provision :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input" >
                                                <input type="text" class="form-control " id="otherField"  name="Budget_Pro"    placeholder="Budget Provision ..." >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                	Available :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="number" class="form-control " id="otherField"  name="Available_No"    placeholder="Available ..." >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                Replacement :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="field_wrapper">
                                                <div class="input">
<!--                                                    <input type="text" name="field_name[]" value=""/>-->

                                                        <input type="text" class="form-control " id="otherField"  name="epf[]"    placeholder="EPF " >
                                                        <input type="text" class="form-control " id="otherField"  name="name[]"    placeholder="Name" >
                                                         <a href="javascript:void(0);" class="add_button" title="Add field"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                	Comments :
                                            </div>
                                            </td>
                                            <td>
                                            <div class="input">
                                                <textarea class="form-control" name="Comments" id="otherField" rows="3"></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                                <span class="text">Reset</span>
                                            </button>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <button TYPE="submit" name="add_re" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                                    <span class="text">Add</span>
                                                </button>

                                            </div>
                                        </td>
                                    </tr>
                                </table>

                            </div>

<!--///////////////////////////////////////////////////////////////////////// New ////////////////////////////////////////////-->

                                <div class="form-group table-second" id="FieldDiv">
                                    <table>
                                        <tr>
                                            <td>
                                                <div class="text-right">
                                                    Designation :
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input">
                                                    <input type="text" class="form-control " id="otherField"  name="designation"    placeholder="designation ..." >
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="text-right">
                                                    No.of Emp. Required :
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input">
                                                    <input type="number" class="form-control " id="otherField"  name="designation"    placeholder="No.of Emp. Required" >
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="text-right">
                                                    Budget Provision :
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input" >
                                                    <input type="text" class="form-control " id="otherField"  name="designation"    placeholder="Budget Provision ..." >
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="text-right">
                                                    Available :
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input">
                                                    <input type="text" class="form-control " id="otherField"  name="designation"    placeholder="Available ..." >
                                                </div>
                                            </td>
                                        </tr>
<!--                                        <tr>-->
<!--                                            <td>-->
<!--                                                <div class="text-right">-->
<!--                                                    Replacement :-->
<!--                                                </div>-->
<!--                                            </td>-->
<!--                                            <td>-->
<!--                                                <div class="input">-->
<!--                                                    <input type="text" class="form-control " id="otherField"  name="designation" required=""   placeholder="EPF " >-->
<!--                                                    <input type="text" class="form-control " id="otherField"  name="designation" required=""   placeholder="Name" >-->
<!---->
<!--                                                </div>-->
<!--                                            </td>-->
<!--                                        </tr>-->
                                        <tr>
                                            <td>
                                                <div class="text-right">
                                                    Comments :
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input">
                                                    <textarea class="form-control" id="otherField" rows="3"></textarea>
                                                </div>
                                            </td>
                                        </tr>
<!--                                        <tr>-->
<!--                                            <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">-->
<!--                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>-->
<!--                                        </span>-->
<!--                                                    <span class="text">Reset</span>-->
<!--                                                </button>-->
<!--                                            </td>-->
<!--                                            <td>-->
<!--                                                <div class="input-group">-->
<!---->
<!--                                                    <button TYPE="submit" name="add_new" class="btn btn-success btn-icon-split">-->
<!--                                        <span class="icon text-white-50"><i class="fas fa-check"></i>-->
<!--                                        </span>-->
<!--                                                        <span class="text">Add</span>-->
<!--                                                    </button>-->
<!---->
<!--                                                </div>-->
<!--                                            </td>-->
<!--                                        </tr>-->
                                    </table>

                                </div>

<!--                                <div class="input-group">-->
<!---->
<!--                                    <button TYPE="submit" name="add_re" class="btn btn-success btn-icon-split">-->
<!--                                        <span class="icon text-white-50"><i class="fas fa-check"></i>-->
<!--                                        </span>-->
<!--                                        <span class="text">Add</span>-->
<!--                                    </button>-->
<!---->
<!--                                </div>-->


















              </form>
</div>


                </div>
            </div>




      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; JJM MIS 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php?token=lo1">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  <SCRIPT>
//      function show(select_item) {
//          if (select_item == "replacement") {
//              hiddenDiv_2.style.visibility='hidden';
//              hiddenDiv_2.style.display='none';
//              hiddenDiv_1.style.visibility='visible';
//              hiddenDiv_1.style.display='block';
//
//
//              Form.fileURL.focus();
//          }else if(select_item == "new"){
//              hiddenDiv_1.style.visibility='hidden';
//              hiddenDiv_1.style.display='none';
//              hiddenDiv_2.style.visibility='visible';
//              hiddenDiv_2.style.display='block';
//              Form.fileURL.focus();
//
//          }
//          else{
//              hiddenDiv_2.style.visibility='hidden';
//              hiddenDiv_2.style.display='none';
//              hiddenDiv_1.style.visibility='hidden';
//              hiddenDiv_1.style.display='none';
//          }
//      }


      $("#seeAnotherField").change(function() {
          if ($(this).val() == "replacement") {
              $('#FieldDiv').hide();
              $('#Field').removeAttr('required');
              $('#Field').removeAttr('data-error');

              $('#otherFieldDiv').show();
              $('#otherField').attr('required', '');
              $('#otherField').attr('data-error', 'This field is required.');
          } else if($(this).val() == "new") {
              $('#otherFieldDiv').hide();
              $('#otherField').removeAttr('required');
              $('#otherField').removeAttr('data-error');

              $('#FieldDiv').show();
              $('#Field').attr('required', '');
              $('#Field').attr('data-error', 'This field is required.');
          }
          else {
              $('#otherFieldDiv').hide();
              $('#otherField').removeAttr('required');
              $('#otherField').removeAttr('data-error');
              $('#FieldDiv').hide();
              $('#Field').removeAttr('required');
              $('#Field').removeAttr('data-error');
          }
      });
      $("#seeAnotherField").trigger("change");

//      $("#seeAnotherFieldGroup").change(function() {
//          if ($(this).val() == "yes") {
//              $('#otherFieldGroupDiv').show();
//              $('#otherField1').attr('required', '');
//              $('#otherField1').attr('data-error', 'This field is required.');
//              $('#otherField2').attr('required', '');
//              $('#otherField2').attr('data-error', 'This field is required.');
//          } else {
//              $('#otherFieldGroupDiv').hide();
//              $('#otherField1').removeAttr('required');
//              $('#otherField1').removeAttr('data-error');
//              $('#otherField2').removeAttr('required');
//              $('#otherField2').removeAttr('data-error');
//          }
//      });
//      $("#seeAnotherFieldGroup").trigger("change");
  </SCRIPT>
  <script type="text/javascript">
      $(document).ready(function(){
          var maxField = 10; //Input fields increment limitation
          var addButton = $('.add_button'); //Add button selector
          var wrapper = $('.field_wrapper'); //Input field wrapper
          var fieldHTML = '<div class="input"><input type="text" class="form-control " id="otherField"  name="epf[]" required=""   placeholder="EPF " ><input type="text" class="form-control " id="otherField"  name="name[]" required=""   placeholder="Name" > <a href="javascript:void(0);" class="remove_button"><i class="fa fa-minus-circle" aria-hidden="true"></i></a> </div>'; //New input field html
          var x = 1; //Initial field counter is 1

          //Once add button is clicked
          $(addButton).click(function(){
              //Check maximum number of input fields
              if(x < maxField){
                  x++; //Increment field counter
                  $(wrapper).append(fieldHTML); //Add field html
              }
          });

          //Once remove button is clicked
          $(wrapper).on('click', '.remove_button', function(e){
              e.preventDefault();
              $(this).parent('div').remove(); //Remove field html
              x--; //Decrement field counter
          });
      });
  </script>


</body>

</html>
