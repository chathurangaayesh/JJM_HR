<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

include 'config/conn.php';
if(isset($_GET['id'])) {
     $encoded = $_GET['id'];
     $decoded_id = base64_decode($encoded);
    $sql="select * from system_users WHERE id = '$decoded_id'";
    $qq=mysqli_query($conn,$sql);
    $rr=mysqli_fetch_assoc($qq);
    $user_name=$rr['user_name'];
}
if(isset($_POST['change'])){
    $user_name=mysqli_real_escape_string($conn, $_POST['U_name']);
    $password=mysqli_real_escape_string($conn, $_POST['password']);
   echo $id=mysqli_real_escape_string($conn, $_POST['id']);
    $h_password=md5($password);

        $sql_2 = " UPDATE system_users SET password='$h_password',login_status=1 WHERE id = '$id'";
        $rr_q = mysqli_query($conn, $sql_2);





    if($rr_q){

     header('location:index.php?token=sus');

        }
    else{
        $error=1;

    }
}

?>




<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>HR System - Login</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <!--<link href="css/HR-admin-2.min.css" rel="stylesheet">-->
  <link href="css/HR-admin-2.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
              <div class="col-lg-6">
                <div class="p-5" align="center">
                  <div class="text-center" >
                    <h1 class="h4 text-gray-900 mb-4">Welcome To HR !</h1>
                    <h1 class="h5 text-gray-900 mb-4">Pleace Change Your Password !</h1>
                  </div>
                  <form class="user d-none d-sm-inline-block  mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $decoded_id ?>"/>
                      <input type="text" class="form-control form-control-user" name="U_name" id="exampleInputEmail" value="<?php echo $user_name ?>" aria-describedby="emailHelp" placeholder="Enter User Name...">
                    </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-user" name="password" id="password"  onkeyup='check();'  placeholder="Password">
                        </div>
                        <div class="form-group">

                            <input type="password" class="form-control form-control-user" name="confirm_password" id="confirm_password"  onkeyup='check();' placeholder="Confirm Password">
                            <span id='message'></span>
                        </div>
<!--        =================================log error===============================================-->
                      <?php
                      if( isset($error)){
                          ?>
                          <div class="col-lg-12 mb-4" id="Bar">
                              <div class="card bg-danger text-white shadow">
                                  <!--                              <div id="right">-->
                                  <!--                                  <a href="#" onclick="Hide(Bar);">X</a>-->
                                  <!--                              </div>-->
                                  <div class="card-body">
                                      Error
                                      <div class="text-white-50 small">You Can not Access</div>
                                  </div>
                              </div>
                          </div>

                          <?php
                      }
                      ?>



                      <div class="form-group">
                        <button TYPE="submit" name="change" class="btn btn-primary btn-user btn-block">Submit</button>
                          </div>


                  </form>


                  <!--<div class="text-center">-->
                    <!--<a class="small" href="register.html">Create an Account!</a>-->
                  <!--</div>-->
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
  <script>
      var check = function() {
          if (document.getElementById('password').value ==
              document.getElementById('confirm_password').value) {
              document.getElementById('message').style.color = 'green';
              document.getElementById('message').innerHTML = 'Matching Password';
          } else {
              document.getElementById('message').style.color = 'red';
              document.getElementById('message').innerHTML = 'Not Matching Password';
          }
      }</script>

</body>

</html>
