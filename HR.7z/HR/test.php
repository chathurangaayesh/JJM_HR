<script>
    $('.chk').change(function () {

        if($(this).is(':checked'))

        {

            $(this).closest('tr').find('td').each(

                function (i) {

                    console.log($(this).text());

                });

        }

    });
</script>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<div id="tablediv">

<table border="1" id="itemtable" align="center">

    <tr>

        <th>check</th>

        <th scope="col">Item name</th>

        <th scope="col">Item code</th>

        <th scope="col">Supplier</th>

        <th scope="col">Received qty</th>

        <th scope="col">Accepted qty</th>

        <th scope="col">Rejected qty</th>

        <th scope="col">Remarks</th>

    </tr>
    <tr>

            <td><input type="checkbox" class="chk" ></td>

        <td>Pencil</td>
        <td>101</td>

        <td>Supplier</td>
        <td>10</td>

        <td>5</td>

        <td>5</td>

        <td>Remarks</td>

    </tr>
     <tr>
         <td><input type="checkbox" class="chk" ></td>
        <td>Pen</td>
        <td>102</td>
        <td>Supplier</td>
        <td>25</td>

        <td>20</td>
        <td>5</td>

        <td>Remarks</td>
    </tr>

</table>

</div>

<script>
    var products = ProductManager.getAllProducts();

    $.each(products, function(){

        var total = this.quantity * this.price;

        $cartTable.append(

            '<tr title="' + this.summary + '" data-id="' + this.id + '" data-price="' + this.price + '">' +

            '<td class="text-center" style="width: 30px;"><img width="30px" height="30px" src="' + this.image + '"/></td>' +

            '<td>' + this.name + '</td>' +

            '<td title="Unit Price">Rs ' + this.price + '</td>' +

            '<td title="Quantity"><input type="number" min="1" style="width: 70px;" class="' + classProductQuantity + '" value="' + this.quantity + '"/></td>' +

            '<td title="Total Amount" class="' + classProductTotal + '"> Rs ' + total + '</td>' +

            '<td title="remark">  <input type="text" id="txtREMARKS" placeholder="Enter your remarks" /> </td>' +

            '<td title="Remove from Cart" class="text-center" style="width: 30px;"><a href="javascript:void(0);" class="btn btn-xs btn-danger ' + classProductRemove + '">X</a></td>' +

            '</tr>'

        );

</script>

