<?php

include_once('config/doc_head.php');
include_once ("class/notifications.php");
$notifications = new notifications();

if(isset($_POST['add'])){
    $No_EMP=mysqli_real_escape_string($conn, $_POST['No_EMP']);
    $designation=mysqli_real_escape_string($conn, $_POST['designation']);
    $Budget_Pro=mysqli_real_escape_string($conn, $_POST['Budget_Pro']);
    $Available_No=mysqli_real_escape_string($conn, $_POST['Available_No']);
    $plant=mysqli_real_escape_string($conn, $_POST['plant']);
    $cluster=mysqli_real_escape_string($conn, $_POST['cluster']);
    $request_date=mysqli_real_escape_string($conn, $_POST['request_date']);

     $Comments=mysqli_real_escape_string($conn, $_POST['Comments']);
    $CREATE_USER=$_SESSION["user_name"];


        $test_new=$_POST['epf'];
    foreach($test_new as $val){
            echo $val;

    if($val!='EPF' ){
        $epf_array=$_POST['epf'];
        $name_array= $_POST['name'];
        $designation_array= $_POST['designation'];
       // print_r($epf_array);
        $sql_req_id_rpl="SELECT COUNT(SUBSTRING(request_id,5,3)) AS request_id FROM manpower_request WHERE LEFT(request_id,3) = 'RPL'";
        $qq_id_rpl=mysqli_query($conn, $sql_req_id_rpl);
        $rr_id_rpl=mysqli_fetch_assoc($qq_id_rpl);
        $request_id_no_rpl=$rr_id_rpl['request_id'];
          $request_id_rpl="RPL0".($request_id_no_rpl+1);

        $sql_1="INSERT INTO manpower_request (request_id,designation , no_of_employees , budget_provision ,available_carder,plant_code,cluster_code,request_date,comments,create_date , create_user )
                      VALUES ('$request_id_rpl','$designation','$No_EMP','$Budget_Pro','$Available_No','$plant','$cluster','$request_date','$Comments',CURRENT_TIMESTAMP ,'$CREATE_USER') ";
        $rr_1=mysqli_query($conn, $sql_1);

        if ($rr_1) {
            $success_rpl=$request_id_rpl;

            $encoded_app='A';
            $success_notify=$notifications->notify($encoded_app,$request_id_rpl,$log_user_id);

        } else {
            //Echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            $error_rpl=$request_id_rpl;//duplicate request id
        }

        foreach(array_combine($epf_array, $name_array) as $code => $name  ){

            $sql_2="INSERT INTO emp_replacment (request_id ,epf ,name,create_date , create_user )
                      VALUES ('$request_id_rpl','$code','$name',CURRENT_TIMESTAMP ,'$CREATE_USER') ";
           // $rr_2=mysqli_query($conn, $sql_2);

        }

    }else{
        $sql_req_id_new="SELECT COUNT(SUBSTRING(request_id,5,3)) AS request_id FROM manpower_request WHERE LEFT(request_id,3) = 'NEW'";
        $qq_id_new=mysqli_query($conn, $sql_req_id_new);
        $rr_id_new=mysqli_fetch_assoc($qq_id_new);
       echo $request_id_no_new=$rr_id_new['request_id'];
        $request_id_new="NEW0".($request_id_no_new+1);
        $sql="INSERT INTO manpower_request (request_id,designation , no_of_employees , budget_provision ,available_carder,plant_code,cluster_code,request_date,comments,create_date , create_user )
                      VALUES ('$request_id_new','$designation','$No_EMP','$Budget_Pro','$Available_No','$plant','$cluster','$request_date','$Comments',CURRENT_TIMESTAMP ,'$CREATE_USER') ";


        $rr_0=mysqli_query($conn, $sql);
        if ($rr_0) {
            $success_new=$request_id_new;
            $encoded_app='A';
            $success_notify=$notifications->notify($encoded_app,$request_id_new,$log_user_id);

        } else {
           Echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            $error_new=$request_id_new;
        }
    }



    }


}




?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JJM HR - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
  <!-- Custom styles for this template-->
  <link href="css/HR-admin-2.css" rel="stylesheet">
    <style>
       . tainer-fluid{
           background-color: #fff;
           border: 1px solid #ccc;

       }
        .table-second{
            padding-top: 10px;
            align-items: center;
            width: 100%;
            margin-left:20%;

        }
        .table-head{
            align-items: center;
        }
        form td{
            padding: 1em 1.2em;
        }
        form{
            background-color: #fff;
            width: 100%;
        }
        .text-right{

            text-align: right;
        }.select{

           margin-left:30px;
                 }
         .select-type{
            display: inline-block;
             width:300px;
             margin:0 auto;

         }
        .input {
                margin-top: 2px;
        }
       #right {
           margin-left: 96%;
           float: right;
           width: 30px;
           height: 20px;
           text-align: center;
       }
       #right a {
           float: right;
           color: #FFFFFF;
           text-decoration: none;
           display: inline-block;
       }
       #right a:hover {
           font-weight: 500;
       }

    </style>
    <script>
        //          ===================================== message box close button =======================================
        function Hide(HideID)
        {
            HideID.style.display = "none";
        }

    </script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-users-cog"></i>
        </div>
        <div class="sidebar-brand-text mx-3">JJM HR <sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Marsters
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Masters</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Users:</h6>

              <a class="collapse-item " href="Department.php">Department</a>
              <a class="collapse-item " href="cluster.php">Cluster</a>
              <a class="collapse-item " href="Company.php">Company</a>
              <a class="collapse-item " href="Role.php">Role </a>
          </div>
        </div>
      </li>



      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Process
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Screens:</h6>
              <a class="collapse-item " href="user_mgt.php">User Registation</a>
            <a class="collapse-item active" href="manpuwer_request.php">Manpower Request</a>
              <a class="collapse-item" href="Request_action.php">Requests Action</a>
<!--            <a class="collapse-item" href="register.html">Register</a>-->
<!--            <a class="collapse-item" href="forgot-password.html">Forgot Password</a>-->
<!--            <div class="collapse-divider"></div>-->
<!--            <h6 class="collapse-header">Other Pages:</h6>-->
<!--            <a class="collapse-item" href="404.html">404 Page</a>-->
<!--            <a class="collapse-item" href="blank.html">Blank Page</a>-->
          </div>
        </div>
      </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <span>Notification</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">More:</h6>
                    <a class="collapse-item " href="notification.php">More Notifications</a>

                </div>
            </div>
        </li>


        <!-- Nav Item - Charts -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="charts.html">-->
<!--          <i class="fas fa-fw fa-chart-area"></i>-->
<!--          <span>Charts</span></a>-->
<!--      </li>-->
<!---->
<!--      <!-- Nav Item - Tables -->-->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="tables.html">-->
<!--          <i class="fas fa-fw fa-table"></i>-->
<!--          <span>Tables</span></a>-->
<!--      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">

                </script>
                <script type="text/javascript">
                var auto_refresh = setInterval(
                    function ()
                    {
                        $('#load_tweets').load('notification_button.php?id=<?php echo $log_username; ?>').fadeIn("slow");
                    }, 10000); // refresh every 10000 milliseconds





                </script>

                <div id="load_tweets"><?php
                    include_once("notification_button.php");
                    ?>
                </div>
            </li>



            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-500 small"><?php echo $fullname;?></span>
                  <img class="img-profile rounded-circle" src="img/profile/<?php echo $profile_pic;?>">

              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                  <a class="dropdown-item" href="user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->

       <div class="con tainer-fluid">
           <!--            //================================================================================Succsess Add Msessage==========================================-->
           <?php if(isset($success_rpl) || isset($success_new) ||  isset($success_notify) ){

                   ?>


                   <div class="col-lg-12 mb-4" id="Bar">
                       <div class="card bg-success text-white shadow">
                           <div id="right">
                               <a href="#" onclick="Hide(Bar);">X</a>
                           </div>
                           <div class="card-body">
                               Success
                               <?php
                               if(isset($success_rpl)){
                                   echo "<div class='text-white-50 small'>New Request Enterd --- Request Id [". $success_rpl."]</div>";
                               }elseif(isset($success_new)){
                                   echo "<div class='text-white-50 small'>New Request Enterd --- Request Id [". $success_new."]</div>";
                               }
                               if($success_notify==1){
                                   echo "<div class='text-white-50 small'>Notification Added</div>";
                               }
                               ?>


                           </div>
                       </div>
                   </div>
               <?php
               }

           ?>
           <!--            //================================================================================Error Add Msessage==========================================-->
           <?php if(isset($error_rpl) || isset($error_new)){

                   ?>


                   <div class="col-lg-12 mb-4" id="Bar">
                       <div class="card bg-danger text-white shadow">
                           <div id="right">
                               <a href="#" onclick="Hide(Bar);">X</a>
                           </div>
                           <div class="card-body">
                               Error
                               <?php
                               if(isset($success_rpl)){
                                   echo "<div class='text-white-50 small'>Duplicate Data ! ==> --- Request Id [". $success_rpl."]</div>";
                               }elseif(isset($success_new)){
                                   echo "<div class='text-white-50 small'>Duplicate Data ! ==> --- Request Id [". $success_new."]</div>";
                               }
                               ?>

                           </div>
                       </div>
                   </div>
               <?php

           }
           ?>

          <!-- Page Heading -->
           <div class="d-sm-flex align-items-center justify-content-between mb-4">
               <h1 class="h3 mb-0 text-gray-800"></h1>

           </div>



            <!-- Pie Chart -->


          <!-- Content Row -->
          <div class="row">

              <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 " action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                  <div align="center">
                      <h1 class="h3  text-gray-800" style="padding-top:10px ">Manpower Request Form</h1>
                      <hr/>
                      <hr/>
                  </div>
            <!-- Content Column -->
              <div class="col-lg-12 " align="center">

                  <table class="table-head">
                  <tr>
                      <?php
                      $sql_plant="SELECT a.plant_name,a.plant_code  FROM  `jjm_plant` a
                                  LEFT JOIN  `system_users` b
                                  ON a.plant_code=b.plant_code
                                  WHERE b.id='$log_user_id'";
                      $rr_plant=mysqli_query($conn, $sql_plant);
                      while($row=mysqli_fetch_assoc($rr_plant)){
                          $plant_name=$row['plant_name'];
                          $plant_code=$row['plant_code'];
                      }

                      ?>
                      <td class="label"><div class="text-right">Plant :</div></td>
                      <td>
                          <div class="input-group">

                              <input type="text" class="form-control " name="plant" value="<?php echo $plant_name; ?>" readonly   placeholder="Plant" >
                              <input type="hidden" class="form-control " name="plant" value="<?php echo $plant_code; ?>" >
                          </div>
                      </td>
                      <td class="label"><div class="text-right">Request Date (Befor) :</div></td>
                      <td>
                          <div class="input-group">
                                <?php $date=date("Y-m-d") ?>
                              <input type="date" class="form-control " name="request_date" required="" min='<?php echo $date;?>'  placeholder="Department Code..." >
                          </div>
                      </td>
                  </tr>
                      <tr>

                              <?php
                              $sql_plant="SELECT a.`cluster_name`,a.`cluster_code`  FROM  `jjm_cluster` a
                                  LEFT JOIN  `system_users` b
                                  ON a.cluster_code=b.cluster_code
                                  WHERE b.id='$log_user_id'";
                              $rr_plant=mysqli_query($conn, $sql_plant);
                              while($row=mysqli_fetch_assoc($rr_plant)){
                                  $cluster_name=$row['cluster_name'];
                                  $cluster_code=$row['cluster_code'];
                              }

                              ?>
                          <td class="label"><div class="text-right">Cluster :</div></td>
                          <td>
                              <div class="input-group">

                                  <input type="text" class="form-control " name="cluster" value="<?php echo $cluster_name; ?>" readonly   placeholder="Plant" >
                                  <input type="hidden" class="form-control " name="cluster" value="<?php echo $cluster_code; ?>" >
                              </div>
                          </td>

                      </tr>
                  </table>
                  <hr/>


              </div>

                    <div class="col-lg-12 ">
                    <div  class="" >




                            <div class="form-group select-type" align="center">
                                <div class="text-right">
                                <label for="seeAnotherField">Request Type</label>
                                </div>
                                <div class="input-group">
                                <select class="form-control select" id="seeAnotherField">

                                    <option value="replacement">Replacement</option>
                                    <option value="new" selected>New</option>
                                </select>
                                    </div>
                            </div>
                                <hr/>


                        <div class="form-group table-second" id="otherFieldDiv" STYLE="margin-top: 10px">
                            <div class="text-right">
                                Replacement :
                            </div>

                            <div class="field_wrapper">
                                <div class="input" style="padding-left: 30px;">


                                    <input type="text" class="form-control " id="otherField"  name="epf[]" value="EPF"   placeholder="EPF " >
                                    <input type="text" class="form-control " id="otherField"  name="name[]"    placeholder="Name" >

                                    <a href="javascript:void(0);" class="add_button" title="Add field"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                                </div>
                            </div>

                        </div>


                        <div class="table-second">
                                <table>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                Designation :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="text" class="form-control " id="otherField" required=""  name="designation"    placeholder="designation ..." >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                No.of Emp. Required :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="number" class="form-control " id="No_EMP"  name="No_EMP"    placeholder="No.of Emp. Required" >

                                                <span id="demo" style="color: red" class="validate_error"></span>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <div class="text-right">
                                               Budget Provision :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input" >
                                                <input type="text" class="form-control " id="otherField" required="" name="Budget_Pro"    placeholder="Budget Provision ..." >
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>

                                        <td>
                                            <div class="text-right">
                                                	Available :
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input">
                                                <input type="number" class="form-control " id="otherField" required="" name="Available_No"    placeholder="Available ..." >
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <div class="text-right">
                                                	Comments :
                                            </div>
                                            </td>
                                            <td>
                                            <div class="input">
                                                <textarea class="form-control" name="Comments" id="otherField" rows="10" placeholder="Nature of Work Increased "></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                                <span class="text">Reset</span>
                                            </button>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <button TYPE="submit" name="add" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                                    <span class="text">Add</span>
                                                </button>

                                            </div>
                                        </td>
                                    </tr>
                                </table>
                        </div>


                        </div>
                        </div>

                  </form>
        </div>

</div>
</div>




      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; JJM MIS 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php?token=lo1">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  <SCRIPT type="text/javascript">


      $("#seeAnotherField").change(function() {
          if ($(this).val() == "replacement") {
              $('#FieldDiv').hide();
              $('#Field').removeAttr('required');
              $('#Field').removeAttr('data-error');

              $('#otherFieldDiv').show();
              $('#otherField').attr('required', '');
              $('#otherField').attr('data-error', 'This field is required.');
          } else if($(this).val() == "new") {
              $('#otherFieldDiv').hide();
              $('#otherField').removeAttr('required');
              $('#otherField').removeAttr('data-error');

              $('#FieldDiv').show();
              $('#Field').attr('required', '');
              $('#Field').attr('data-error', 'This field is required.');
          }
          else {
              $('#otherFieldDiv').hide();
              $('#otherField').removeAttr('required');
              $('#otherField').removeAttr('data-error');
              $('#FieldDiv').hide();
              $('#Field').removeAttr('required');
              $('#Field').removeAttr('data-error');
          }
      });
      $("#seeAnotherField").trigger("change");


  </SCRIPT>
  <script type="text/javascript">
      $(document).ready(function(){
            var count=1;
      $(document).ready(function(){
          var maxField = 10; //Input fields increment limitation
          var addButton = $('.add_button'); //Add button selector
          var wrapper = $('.field_wrapper'); //Input field wrapper
          var fieldHTML = '<div class="input"><input type="text" class="form-control " id="otherField"  name="epf[]" required=""   placeholder="EPF " ><input type="text" class="form-control " id="otherField"  name="name[]" required=""   placeholder="Name" > <a href="javascript:void(0);" class="remove_button"><i class="fa fa-minus-circle" aria-hidden="true"></i></a> </div>'; //New input field html

          var x = 1; //Initial field counter is 1

          //Once add button is clicked
          $(addButton).click(function(){
              //Check maximum number of input fields

              if(x < maxField){

                  x++; //Increment field counter
                  $(wrapper).append(fieldHTML); //Add field html
                  document.getElementById("demo").innerHTML ='Please Maximum value must be '+ x;
              }




          });

          //Once remove button is clicked
          $(wrapper).on('click', '.remove_button', function(e){
              e.preventDefault();
              $(this).parent('div').remove(); //Remove field html
              x--; //Decrement field counter
              document.getElementById("demo").innerHTML ='Please Maximum value must be '+x;
          });



      });




      });
  </script>


</body>

</html>
