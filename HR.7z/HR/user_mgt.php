<?php
include_once('config/doc_head.php');




include 'config/conn.php';


if(isset($_GET['token_del']))
{
    $suscceess='';
   $encoded=$_GET['token_del'];
    $decoded = base64_decode($encoded);
   $sql_del = "DELETE FROM system_users WHERE id='$decoded'";

if (mysqli_query($conn, $sql_del)) {
    $suscceess=3;
}else{
    $suscceess=0;
}

}
if(isset($_POST['add'])){
    $suscceess='';
    $user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $h_password=md5($password);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $sex = mysqli_real_escape_string($conn, $_POST['sex']);
    $TEL = mysqli_real_escape_string($conn, $_POST['TEL']);
    $EID = mysqli_real_escape_string($conn, $_POST['EID']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $dept_code = mysqli_real_escape_string($conn, $_POST['dept_code']);
    $company_code = mysqli_real_escape_string($conn, $_POST['company_code']);
    $cluster_code = mysqli_real_escape_string($conn, $_POST['cluster_code']);
    $plant_code = mysqli_real_escape_string($conn, $_POST['plant_code']);
    $role_code = mysqli_real_escape_string($conn, $_POST['role_code']);
    $CREATE_USER=$_SESSION["user_name"];


//    level valus get from array
    if(isset($_POST['level_1'])){
        echo $level_1=1;
    }else{
        echo $level_1=0;
    }
    if(isset($_POST['level_2'])){
        echo $level_2=1;
    }else{
        echo $level_2=0;
    }
    if(isset($_POST['level_3'])){
        echo $level_3=1;
    }else{
        echo $level_3=0;
    }
    if(isset($_POST['level_4'])){
        echo $level_4=1;
    }else{
        echo $level_4=0;
    }
    if(isset($_POST['US'])){
        echo $US=1;
    }else{
        echo $US=0;
    }
    if(isset($_POST['UK'])){
        echo $UK=1;
    }else{
        echo $UK=0;
    }




    $sql="INSERT INTO system_users (user_name,password,full_name,email_address,emp_id,sex,designation,role,privilege_code,company_code,cluster_code,dept_code,plant_code,tel_1,tel_2,nic,profile_pic,login_status,is_enable,Approve_level_1,Approve_level_2,Approve_level_3,Approve_level_4,Approve_US,Approve_UK,create_date,create_user )
                         VALUES ('$user_name','$h_password','$name','$email','$EID','$sex','$designation','$role_code','', '$company_code','$cluster_code','$dept_code','$plant_code', '$TEL','','','user.png',0,1,'$level_1','$level_2','$level_3','$level_4','$US','$UK', CURRENT_TIMESTAMP ,'$CREATE_USER') ";


    if (mysqli_query($conn, $sql)) {
        $suscceess=1;
       // echo "ssss";

    } else {
       // Echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        $suscceess=0;
      }
}

//======================== edite=========
if(isset($_POST['edit'])){
    $suscceess='';
    $user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
//    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $h_password=md5($password);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $sex = mysqli_real_escape_string($conn, $_POST['sex']);
    $TEL = mysqli_real_escape_string($conn, $_POST['TEL']);
    $EID = mysqli_real_escape_string($conn, $_POST['EID']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $dept_code = mysqli_real_escape_string($conn, $_POST['dept_code']);
    $company_code = mysqli_real_escape_string($conn, $_POST['company_code']);
    $cluster_code = mysqli_real_escape_string($conn, $_POST['cluster_code']);
    $plant_code = mysqli_real_escape_string($conn, $_POST['plant_code']);
    $role_code = mysqli_real_escape_string($conn, $_POST['role_code']);

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $is_enable = mysqli_real_escape_string($conn, $_POST['is_enable']);

//    level 1 valus
    if(isset($_POST['level_1_old']) && !(isset($_POST['level_1_new']))){
        echo $level_1=1;
       // echo "----------";
    }elseif(!(isset($_POST['level_1_old'])) && !(isset($_POST['level_1_new']))){
        echo $level_1=0;
       // echo "----------";
    }elseif(!(isset($_POST['level_1_old'])) && isset($_POST['level_1_new'])){
        echo $level_1=1;
       // echo "----------";
    }

    //    level 2 valus
    if(isset($_POST['level_2_old']) && !(isset($_POST['level_2_new']))){
        echo $level_2=1;
        // echo "----------";
    }elseif(!(isset($_POST['level_2_old'])) && !(isset($_POST['level_2_new']))){
        echo $level_2=0;
        // echo "----------";
    }elseif(!(isset($_POST['level_2_old'])) && isset($_POST['level_2_new'])){
        echo $level_2=1;
        // echo "----------";
    }
    //    level 3 valus
    if(isset($_POST['level_3_old']) && !(isset($_POST['level_3_new']))){
        echo $level_3=1;
        // echo "----------";
    }elseif(!(isset($_POST['level_3_old'])) && !(isset($_POST['level_3_new']))){
        echo $level_3=0;
        // echo "----------";
    }elseif(!(isset($_POST['level_3_old'])) && isset($_POST['level_3_new'])){
        echo $level_3=1;
        // echo "----------";
    }
    //    level 4 valus
    if(isset($_POST['level_4_old']) && !(isset($_POST['level_4_new']))){
        echo $level_4=1;
        // echo "----------";
    }elseif(!(isset($_POST['level_4_old'])) && !(isset($_POST['level_4_new']))){
        echo $level_4=0;
        // echo "----------";
    }elseif(!(isset($_POST['level_4_old'])) && isset($_POST['level_4_new'])){
        echo $level_4=1;
        // echo "----------";
    }



    $sql_2="UPDATE system_users SET user_name = '$user_name', full_name= '$name',email_address='$email',sex='$sex',emp_id='$EID',Approve_level_1='$level_1',Approve_level_2='$level_2',Approve_level_3='$level_3',,Approve_level_4='$level_4',
                        designation='$designation',role='$role_code',company_code='$company_code',cluster_code='$cluster_code',dept_code='$dept_code',plant_code='$plant_code',tel_1='$TEL',is_enable='$is_enable'
              WHERE id = $id;";

//Approve_level_1,Approve_level_2,Approve_level_3,Approve_level_4
    if (mysqli_query($conn, $sql_2)) {
        $suscceess=2;
    } else {
        echo "Error: " . $sql_2 . "<br>" . mysqli_error($conn);

    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JJM HR -Registation User</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
  <!-- Custom styles for this template-->
  <link href="css/HR-admin-2.css" rel="stylesheet">
    <style>
        .tab-pane {

            background-color: #fff;
            border: 1px solid #ccc;
            border-top: none;
            border-radius: 0 0 4px 4px;

        }
        form{
            padding-top: 20px;
            padding-left: 200px;

        }
        form td{
            padding: 1em 1.2em;
        } #right {
              margin-left: 96%;
              float: right;
              width: 30px;
              height: 20px;
              text-align: center;
          }
        .input  {
            float: left;
            margin-left: 10px;
            display: inline-block;
        }
        #right a:hover {
            font-weight: 500;
        }.checkbox{

                     /* Double-sized Checkboxes */
                     -ms-transform: scale(2); /* IE */
                     -moz-transform: scale(2); /* FF */
                     -webkit-transform: scale(2); /* Safari and Chrome */
                     -o-transform: scale(2); /* Opera */
                     padding: 5px;
                    margin-top: 10px;
                    margin-left: 10px;
                 }

    </style>
    <script>
        //          ===================================== message box close button =======================================
        function Hide(HideID)
        {
            HideID.style.display = "none";
        }

    </script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-users-cog"></i>
        </div>
        <div class="sidebar-brand-text mx-3">JJM HR  <sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Interface
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-cog"></i>
                <span>Masters</span>
            </a>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Users:</h6>

                    <a class="collapse-item " href="Department.php">Department</a>
                    <a class="collapse-item " href="cluster.php">Cluster</a>
                    <a class="collapse-item " href="Company.php">Company</a>
                    <a class="collapse-item " href="Role.php">Role </a>
                </div>
            </div>
        </li>




      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Process
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header"> Screens:</h6>
              <a class="collapse-item active" href="user_mgt.php">User Registation</a>

              <a class="collapse-item " href="manpuwer_request.php">Manpower Request</a>
                <a class="collapse-item" href="Request_action.php">Requests Action</a>
<!--            <a class="collapse-item" href="forgot-password.html">Forgot Password</a>-->
<!--            <div class="collapse-divider"></div>-->
<!--            <h6 class="collapse-header">Other Pages:</h6>-->
<!--            <a class="collapse-item" href="404.html">404 Page</a>-->
<!--            <a class="collapse-item" href="blank.html">Blank Page</a>-->
          </div>
        </div>

      </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-address-card" aria-hidden="true"></i>
                <span>New</span>
            </a>
            <div id="collapse" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">New Employee:</h6>
                    <a class="collapse-item " href="approved_request.php">Approved Request</a>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="approved_applicant_cv.php">Applicants</a>';
                    }?>

                    <?php if(($setting->roleValQyesry($log_username))=='HROfficer') {
                        echo '<a class="collapse-item " href="calling_interview.php">Calling For interview</a>';
                        //echo $log_username ;
                    }?>
                    <?php if(($setting->roleValQyesry($log_username))=='DPTHead') {
                        echo '<a class="collapse-item " href="inteview_shedule_approve.php">Sheduled Interview</a>';
                    }?>
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <span>Notification</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">More:</h6>
                    <a class="collapse-item " href="notification.php">More Notifications</a>

                </div>
            </div>
        </li>

<!--      <!-- Nav Item - Charts -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="charts.html">-->
<!--          <i class="fas fa-fw fa-chart-area"></i>-->
<!--          <span>Charts</span></a>-->
<!--      </li>-->
<!---->
<!--      <!-- Nav Item - Tables -->
<!--      <li class="nav-item">-->
<!--        <a class="nav-link" href="tables.html">-->
<!--          <i class="fas fa-fw fa-table"></i>-->
<!--          <span>Tables</span></a>-->
<!--      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">

                </script>
                <script type="text/javascript">
                var auto_refresh = setInterval(
                    function ()
                    {
                        $('#load_tweets').load('notification_button.php?id=<?php echo $log_username; ?>').fadeIn("slow");
                    }, 10000); // refresh every 10000 milliseconds





                </script>

                <div id="load_tweets"><?php
                    include_once("notification_button.php");
                    ?>
                </div>
            </li>

            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter">7</span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been having.</div>
                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/AU4VPcFN4LE/60x60" alt="">
                    <div class="status-indicator"></div>
                  </div>
                  <div>
                    <div class="text-truncate">I have the photos that you ordered last month, how would you like them sent to you?</div>
                    <div class="small text-gray-500">Jae Chun · 1d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/CS2uCrpNzJY/60x60" alt="">
                    <div class="status-indicator bg-warning"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Last month's report looks great, I am very happy with the progress so far, keep up the good work!</div>
                    <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div>
                    <div class="text-truncate">Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</div>
                    <div class="small text-gray-500">Chicken the Dog · 2w</div>
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="mr-2 d-none d-lg-inline text-gray-500 small"><?php echo $fullname;?></span>
                  <img class="img-profile rounded-circle" src="img/profile/<?php echo $profile_pic;?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                  <a class="dropdown-item" href="user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!--            //================================================================================Succsess Add Msessage==========================================-->
            <?php if(isset($suscceess) ){
                if($suscceess==1 ||$suscceess ==2 || $suscceess=3){
                    ?>


                    <div class="col-lg-12 mb-4" id="Bar">
                        <div class="card bg-success text-white shadow">
                            <div id="right">
                                <a href="#" onclick="Hide(Bar);">X</a>
                            </div>
                            <div class="card-body">
                                Success
                                <?php
                                if($suscceess==1){
                                    echo "<div class='text-white-50 small'>New User Entred</div>";
                                }elseif($suscceess==2){
                                    echo "<div class='text-white-50 small'>Edit User</div>";
                                }elseif($suscceess==3){
                                    echo "<div class='text-white-50 small'>Delete User Success</div>";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                <?php
                }
            }
            ?>
            <!--            //================================================================================Error Add Msessage==========================================-->
            <?php if(isset($suscceess)){
                if($suscceess==0 ){
                    ?>


                    <div class="col-lg-12 mb-4" id="Bar">
                        <div class="card bg-danger text-white shadow">
                            <div id="right">
                                <a href="#" onclick="Hide(Bar);">X</a>
                            </div>
                            <div class="card-body">
                                Error
                                <div class="text-white-50 small">Duplicate Data ! Cluster olredy Exist</div>
                            </div>
                        </div>
                    </div>
                <?php
                }
            }
            ?>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Registation</h1>
          </div>

          <div class="row">
              <div class="col-lg-12">
              <nav>
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                      <?php
                      if(isset($_GET['token'])){
                      ?>
                      <a class="nav-item nav-link " id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Users</a>
                      <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">New User</a>
                          <a class="nav-item nav-link active" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="true">Edit User </a>
                      <?php
                      }else{
                      ?>
                      <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Users</a>
                      <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">New User</a>

                      <?php }
                      ?>
                  </div>
              </nav>
                  </div>
              <div class="col-lg-12">
              <div class="tab-content" id="nav-tabContent">
                  <?php
                  if(isset($_GET['token'])){

                      echo "<div class='tab-pane fade ' id='nav-home' role='tabpanel' aria-labelledby='nav-home-tab'>";

                  }else{
                      echo "<div class='tab-pane fade show active' id='nav-home' role='tabpanel' aria-labelledby='nav-home-tab'>";
                  }
                  ?>


                              <div class="container-fluid">
                                  <div class="card-body">
                                      <div class="table-responsive">
                                          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                              <thead>
                                              <tr>
                                                  <th>Name</th>
                                                  <th>Email</th>
                                                  <th>Position</th>
                                                  <th>role</th>
                                                  <th>Company </th>
                                                  <th>Cluster </th>
                                                  <th>Department</th>
                                                  <th>Plant </th>
                                                  <th>Mobile</th>
                                                  <th>Action</th>
                                              </tr>
                                              </thead>
                                              <tfoot>
                                              <tr>
                                                  <th>Name</th>
                                                  <th>Email</th>
                                                  <th>Designation</th>
                                                  <th>role</th>
                                                  <th>Company </th>
                                                  <th>Cluster </th>
                                                  <th>Department</th>
                                                  <th>Plant </th>
                                                  <th>Mobile</th>
                                                  <th>Action</th>

                                              </tr>
                                              </tfoot>
                                              <tbody style="height: 10px !important; overflow: scroll; ">
                                              <?php
                                              $sql_1="SELECT * FROM `system_users` ";

                                              $QQ=mysqli_query($conn, $sql_1);
                                              $script_name=basename($_SERVER['PHP_SELF']);
                                              while ($RR=mysqli_fetch_assoc($QQ)){
                                                  $id=$RR['id'];

                                                  $string  = $id;
                                                  $encoded = base64_encode($string);

                                                  echo "<tr>
                                                  <td>".$RR['full_name']."</td>
                                                  <td>".$RR['email_address']."</td>
                                                  <td>".$RR['designation']."</td>
                                                  <td>".$RR['role']."</td>
                                                  <td>".$RR['company_code']."</td>
                                                  <td>".$RR['cluster_code']."</td>
                                                  <td>".$RR['dept_code']."</td>
                                                  <td>".$RR['plant_code']."</td>
                                                  <td>".$RR['tel_1']."</td>


                                                         <td >";

                                                  echo '<a class="btn btn-default btn-flat" href="'.$script_name.'?token='.$id.'"  data-toggle="tooltip" ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
                                                  echo '<a class="btn btn-default btn-flat delete" href="'.$script_name.'?token_del='.$encoded.'" data-toggle="tooltip" data-confirm="Are you sure to delete this item?"><i class="fa fa-trash" aria-hidden="true"></i></a>';


                                                  echo"    </td></tr>";
                                              }
                                              ?>


                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                        </div>


                  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">

                      <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                      <table>
                          <tr>
                              <td class="label"><div class="text-right">User Name :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" name="user_name" class="form-control " required=""  placeholder="User Name" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td class="label"><div class="text-right">Full Name :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" name="name" class="form-control "   placeholder="Ful Name" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td class="label"><div class="text-right"> Password :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" name="password" class="form-control " required placeholder="Password" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td class="label"><div class="text-right">Email :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="email" name="email" class="form-control " required placeholder="Email" >
                                  </div>
                              </td>
                          </tr>

                          <tr>
                              <td><div class="text-right">Employye ID :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="number" name="EID" class="form-control " required placeholder="Employye ID" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Sex :</div></td>
                              <td>
                                  <div class="input-group">


                                      <select class="browser-default custom-select" required name="sex">
                                          <option selected value="male">Male</option>
                                          <option  value="female">Female</option>
                                      </select>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Mobile :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" name="TEL" class="form-control " required  pattern="[0-9]{10}" placeholder="Contact Number" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td class="label"><div class="text-right">Designation :</div></td>
                              <td>
                                  <div class="input-group">
                                      <input type="text" name="designation" class="form-control "  required placeholder="designation" >
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Company :</div></td>
                              <td>
                                  <div class="input-group">
                                      <select class="browser-default custom-select" required name="company_code">
                                          <option selected>Select Company</option>
                                          <?php
                                          $sql_5="SELECT * FROM `jjm_company` ";
                                          $QQ_5=mysqli_query($conn, $sql_5);

                                          while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                              echo "  <option  value='".$RR_5['company_code']."'>".$RR_5['company_name']."</option>";
                                              // echo $RR_2['cluster_code'];
                                              // echo $RR_2['cluster_name'];
                                              // echo "<option name='cluster_code' value="1">One</option>";
                                          }
                                          ?>

                                      </select>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Cluster :</div></td>
                              <td>
                                  <div class="input-group">
                                      <select class="browser-default custom-select"  required name="cluster_code">
                                          <option selected>Select Cluster</option>
                                          <?php
                                          $sql_5="SELECT * FROM `jjm_cluster` ";
                                          $QQ_5=mysqli_query($conn, $sql_5);

                                          while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                              echo "  <option  value='".$RR_5['cluster_code']."'>".$RR_5['cluster_name']."</option>";
                                              // echo $RR_2['cluster_code'];
                                              // echo $RR_2['cluster_name'];
                                              // echo "<option name='cluster_code' value="1">One</option>";
                                          }
                                          ?>

                                      </select>
                                  </div>
                              </td>
                          </tr>


                          <tr>
                              <td><div class="text-right">Plant name :</div></td>
                              <td>
                                  <div class="input-group">
                                      <select class="browser-default custom-select" required="" name="plant_code">
                                          <option selected>Select Plant</option>
                                          <?php
                                          $sql_5="SELECT * FROM `jjm_plant` ";
                                          $QQ_5=mysqli_query($conn, $sql_5);

                                          while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                              echo "  <option  value='".$RR_5['plant_code']."'>".$RR_5['plant_name']."</option>";
                                              // echo $RR_2['cluster_code'];
                                              // echo $RR_2['cluster_name'];
                                              // echo "<option name='cluster_code' value="1">One</option>";
                                          }
                                          ?>

                                      </select>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">Department :</div></td>
                              <td>
                                  <div class="input-group">
                                      <select class="browser-default custom-select" required="" name="dept_code">
                                          <option selected>Select Department</option>
                                          <?php
                                          $sql_3="SELECT * FROM `department` ";
                                          $QQ_2=mysqli_query($conn, $sql_3);

                                          while ($RR_2=mysqli_fetch_assoc($QQ_2)){
                                              echo "  <option  value='".$RR_2['dept_code']."'>".$RR_2['dept_name']."</option>";
                                              // echo $RR_2['cluster_code'];
                                              // echo $RR_2['cluster_name'];
                                              // echo "<option name='cluster_code' value="1">One</option>";
                                          }
                                          ?>

                                      </select>



                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td><div class="text-right">User Role :</div></td>
                              <td>
                                  <div class="input-group">
                                      <select class="browser-default custom-select" required name="role_code">
                                          <option selected>Select Role</option>
                                          <?php
                                          $sql_6="SELECT * FROM `user_roles` ";
                                          $QQ_6=mysqli_query($conn, $sql_6);

                                          while ($RR_6=mysqli_fetch_assoc($QQ_6)){
                                              echo "  <option  value='".$RR_6['role_code']."'>".$RR_6['description']."</option>";
                                              // echo $RR_2['cluster_code'];
                                              // echo $RR_2['cluster_name'];
                                              // echo "<option name='cluster_code' value="1">One</option>";
                                          }
                                          ?>

                                      </select>
                                  </div>
                              </td>
                          </tr>
                          <tr>
                              <td ><div class="text-right">Approve Levels :</div></td>
                              <td>
                                  <DIV CLASS=" custom-checkbox">
                                     <div class="input-group" style="float: left">  Level 1 Approve :</div> <div class="input"><input type="checkbox" name="level_1" value="level_1" class="checkbox"></div>
                                      <br/>
                                      <div class="input-group" style="float: left"> Level 2 Approve  : </div><div class="input"><input type="checkbox" name="level_2" value="level_2" class="checkbox"></div>
                                      <br/>
                                          <div class="input-group" style="float: left"> Level 3 Approve  :</div> <div class="input"><input type="checkbox" name="level_3" value="level_3" class="checkbox"></div>
                                      <br/>
                                              <div class="input-group" style="float: left">Level 4 Approve  :</div> <div class="input"><input type="checkbox" name="level_4" value="level_4" class="checkbox"></div>

                                  </DIV>

                              </td>

                          </tr>
                          <tr>
                              <td ><div class="text-right">Approve Clusters :</div></td>
                              <td>
                                  <DIV CLASS="custom-control custom-checkbox">
                                      US : <input type="checkbox" name="US" value="US" class="checkbox"><br/>
                                      UK : <input type="checkbox" name="UK" value="UK" class="checkbox"><br/>

                                  </DIV>

                              </td>

                          </tr>
                          <tr>
                              <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                      <span class="text">Reset</span>
                                  </button>
                              </td>
                              <td>
                                  <div class="input-group">

                                      <button TYPE="submit" name="add" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                          <span class="text">Add</span>
                                      </button>

                                  </div>
                              </td>
                          </tr>

                      </table>

                  </form>
                  </div>

                  <!--                 ==================================================================== edite ======================= ==-->
                  <?php
                  if(isset($_GET['token'])) {
                  ?>
                  <div class="tab-pane fade show active" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                      <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                          <?php
                          $id=$_GET['token'];
                          $sql_2="SELECT * FROM `system_users` where id=$id";
                          $QQ_2=mysqli_query($conn, $sql_2);

                          while ($RR_2=mysqli_fetch_assoc($QQ_2)){
                              $user_name= $RR_2['user_name'];
                              $full_name= $RR_2['full_name'];
                              $description= $RR_2['designation'];
                              $email_address= $RR_2['email_address'];
                              $sex= $RR_2['sex'];
                              $designation= $RR_2['designation'];
                              $role= $RR_2['role'];
                              $company_code= $RR_2['company_code'];
                              $cluster_code= $RR_2['cluster_code'];
                              $dept_code= $RR_2['dept_code'];
                              $plant_code= $RR_2['plant_code'];
                              $tel_1= $RR_2['tel_1'];
                              $emp_id= $RR_2['emp_id'];
                              $is_enable= $RR_2['is_enable'];
                              $Approve_level_1= $RR_2['Approve_level_1'];
                              $Approve_level_2= $RR_2['Approve_level_2'];
                              $Approve_level_3= $RR_2['Approve_level_3'];
                              $Approve_level_4= $RR_2['Approve_level_4'];
                          }
                          //
                          //                          ?>

                          <table>
                              <tr>
                                  <td class="label"><div class="text-right">User Name :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="hidden"  name="id" value="<?php echo $id; ?>" >
                                          <input type="text" name="user_name" class="form-control " required="" value="<?php echo $user_name; ?>"   placeholder="User Name" >
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td class="label"><div class="text-right">Full Name :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="text" name="name" class="form-control "  value="<?php echo $full_name; ?>"   placeholder="Ful Name" >
                                      </div>
                                  </td>
                              </tr>
<!--                              <tr>-->
<!--                                  <td class="label"><div class="text-right"> Password :</div></td>-->
<!--                                  <td>-->
<!--                                      <div class="input-group">-->
<!--                                          <input type="text" name="password" class="form-control " required placeholder="Password" >-->
<!--                                      </div>-->
<!--                                  </td>-->
<!--                              </tr>-->
                              <tr>
                                  <td class="label"><div class="text-right">Email :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="email" name="email" class="form-control " value="<?php echo $email_address; ?>"  required placeholder="Email" >
                                      </div>
                                  </td>
                              </tr>

                              <tr>
                                  <td><div class="text-right">Employye ID :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="number" name="EID" class="form-control " value="<?php echo $emp_id; ?>" required placeholder="Employye ID" >
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">Sex :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select" required name="sex">
                                              <option selected value="<?php echo $sex; ?>"><?php echo $sex; ?></option>
                                              <option  value="male">Male</option>
                                              <option  value="female">Female</option>
                                          </select>
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">Mobile :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="text" name="TEL" class="form-control " value="<?php echo $tel_1; ?>" required  pattern="[0-9]{10}" placeholder="Contact Number" >
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td class="label"><div class="text-right">Designation :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <input type="text" name="designation" class="form-control " value="<?php echo $description; ?>" required placeholder="designation" >
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">Company :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select" required name="company_code">
                                              <option selected value="<?php echo $company_code; ?>"><?php echo $company_code; ?></option>
                                              <?php
                                              $sql_5="SELECT * FROM `jjm_company` ";
                                              $QQ_5=mysqli_query($conn, $sql_5);

                                              while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                                  echo "  <option  value='".$RR_5['company_code']."'>".$RR_5['company_name']."</option>";
                                                  // echo $RR_2['cluster_code'];
                                                  // echo $RR_2['cluster_name'];
                                                  // echo "<option name='cluster_code' value="1">One</option>";
                                              }
                                              ?>

                                          </select>
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">Cluster :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select"  required name="cluster_code">
                                              <option selected value="<?php echo $cluster_code; ?>"><?php echo $cluster_code; ?></option>
                                              <?php
                                              $sql_5="SELECT * FROM `jjm_cluster` ";
                                              $QQ_5=mysqli_query($conn, $sql_5);

                                              while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                                  echo "  <option  value='".$RR_5['cluster_code']."'>".$RR_5['cluster_name']."</option>";
                                                  // echo $RR_2['cluster_code'];
                                                  // echo $RR_2['cluster_name'];
                                                  // echo "<option name='cluster_code' value="1">One</option>";
                                              }
                                              ?>

                                          </select>
                                      </div>
                                  </td>
                              </tr>


                              <tr>
                                  <td><div class="text-right">Plant name :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select" required="" name="plant_code">
                                              <option selected value="<?php echo $plant_code; ?>"><?php echo $plant_code; ?></option>
                                              <?php
                                              $sql_5="SELECT * FROM `jjm_plant` ";
                                              $QQ_5=mysqli_query($conn, $sql_5);

                                              while ($RR_5=mysqli_fetch_assoc($QQ_5)){
                                                  echo "  <option  value='".$RR_5['plant_code']."'>".$RR_5['plant_name']."</option>";
                                                  // echo $RR_2['cluster_code'];
                                                  // echo $RR_2['cluster_name'];
                                                  // echo "<option name='cluster_code' value="1">One</option>";
                                              }
                                              ?>

                                          </select>
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">Department :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select" required="" name="dept_code">
                                              <option selected value="<?php echo $dept_code; ?>"><?php echo $dept_code; ?></option>
                                              <?php
                                              $sql_3="SELECT * FROM `department` ";
                                              $QQ_2=mysqli_query($conn, $sql_3);

                                              while ($RR_2=mysqli_fetch_assoc($QQ_2)){
                                                  echo "  <option  value='".$RR_2['dept_code']."'>".$RR_2['dept_name']."</option>";
                                                  // echo $RR_2['cluster_code'];
                                                  // echo $RR_2['cluster_name'];
                                                  // echo "<option name='cluster_code' value="1">One</option>";
                                              }
                                              ?>

                                          </select>



                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td><div class="text-right">User Role :</div></td>
                                  <td>
                                      <div class="input-group">
                                          <select class="browser-default custom-select" required name="role_code">
                                              <option selected value="<?php echo $role; ?>"><?php echo $role; ?></option>
                                              <?php
                                              $sql_6="SELECT * FROM `user_roles` ";
                                              $QQ_6=mysqli_query($conn, $sql_6);

                                              while ($RR_6=mysqli_fetch_assoc($QQ_6)){
                                                  echo "  <option  value='".$RR_6['role_code']."'>".$RR_6['description']."</option>";
                                                  // echo $RR_2['cluster_code'];
                                                  // echo $RR_2['cluster_name'];
                                                  // echo "<option name='cluster_code' value="1">One</option>";
                                              }
                                              ?>

                                          </select>
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <td ><div class="text-right">Approve Levels :</div></td>
                                  <td>
                                      <DIV CLASS=" custom-checkbox">
                                        <?php  if($Approve_level_1==1){
                                         echo '<div class="input-group" style="float: left">  Level 1 Approve :</div> <div class="input"><input checked type="checkbox" name="level_1_old" value="level_1" class="checkbox"></div>
                                          <br/>';
                                        }else {
                                            echo '<div class="input - group" style="float: left">  Level 1 Approve :</div> <div class="input"><input type="checkbox" name="level_1_new" value="level_1" class="checkbox"></div>
                                          <br/>';
                                        }
                                        ?><?php  if($Approve_level_2==1){
                                         echo ' <div class="input-group" style="float: left"> Level 2 Approve  : </div><div class="input"><input checked type="checkbox" name="level_2_old" value="level_2" class="checkbox"></div>
                                          <br/>';
                                        }else {
                                            echo ' <div class="input-group" style="float: left"> Level 2 Approve  : </div><div class="input"><input type="checkbox" name="level_2_new" value="level_2" class="checkbox"></div>
                                          <br/>>';
                                        }
                                        ?><?php  if($Approve_level_3==1){
                                         echo '
                                          <div class="input-group" style="float: left"> Level 3 Approve  :</div> <div class="input"><input checked type="checkbox" name="level_3_old" value="level_3" class="checkbox"></div>
                                          <br/>';
                                        }else {
                                            echo '
                                          <div class="input-group" style="float: left"> Level 3 Approve  :</div> <div class="input"><input type="checkbox" name="level_3_new" value="level_3" class="checkbox"></div>
                                          <br/>';
                                        }
                                        ?><?php  if($Approve_level_4==1){
                                         echo ' <div class="input-group" style="float: left">Level 4 Approve  :</div> <div class="input"><input checked type="checkbox" name="level_4_old" value="level_4" class="checkbox"></div>';
                                        }else {
                                            echo ' <div class="input-group" style="float: left">Level 4 Approve  :</div> <div class="input"><input type="checkbox" name="level_4_new" value="level_4" class="checkbox"></div>';
                                        }
                                        ?>



                                      </DIV>

                                  </td>

                              </tr>
                              <tr >

                                  <td >
                                      <div class="text-right">Is Enable :</div></td>
                                  </td>

                                      <div class="input-group">
                                      <?php
                                      if($is_enable==1){
                                          echo "<td > <lable class='checkbox_lable'>Enable</lable><input type='radio' checked name='is_enable' class='form-control ' value='1'  placeholder='designation' >
                                                    <lable class='checkbox_lable'>Disable</lable><input type='radio' s name='is_enable' class='form-control ' value='0'  placeholder='designation' ></td>";
                                      }else{
                                          echo " <td ><lable class='checkbox_lable'>Disable</lable><input type='radio' checked s name='is_enable' class='form-control ' value='0'  placeholder='designation' >
                                          <lable class='checkbox_lable'>Enable</lable><input type='radio'  name='is_enable' class='form-control ' value='1'  placeholder='designation' ></td>";
                                      }
                                      ?>
                                      </div>

                              </tr>
<!--                              <tr>-->
<!--                                  <td >-->
<!--                                      <div class="text-right">Edite Is Enable :</div>-->
<!--                                  </td>-->
<!--                                  <td>-->
<!--                                      <lable class='checkbox_lable'>Enable</lable><input type='radio'  name='is_enable' class='form-control ' value='1'  placeholder='designation' >-->
<!--                                       <lable class='checkbox_lable'>Disable</lable><input type='radio' s name='is_enable' class='form-control ' value='0'  placeholder='designation' >-->
<!--                                  </td>-->
<!---->
<!--                              </tr>-->
                              <tr>

                                  <td> <button TYPE="reset"  class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-trash "></i>
                                        </span>
                                          <span class="text">Reset</span>
                                      </button>
                                  </td>
                                  <td>
                                      <div class="input-group">

                                          <button TYPE="submit" name="edit" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50"><i class="fas fa-check"></i>
                                        </span>
                                              <span class="text">Edit</span>
                                          </button>

                                      </div>
                                  </td>
                              </tr>

                          </table>

                      </form>
                  </div>
                  <?php
                  }
                  ?>

              </div>








                  </div>







</div>
            <!-- Pending Requests Card Example -->




        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php?token=lo1">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
      <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
      <script>
          $(function () {
              $("#USERS").css("display", "block");
              $("div.tab button:first-child" ).addClass(" active");
              $(".content").click(function () {

                  var links = document.getElementsByClassName("links");
                  for (i = 0; i < links.length; i++) {
                      links[i].className = links[i].className.replace("active", "");
                  }
              });
          });

          function openLang(e, lang) {
              var links = document.getElementsByClassName("links");
              var content = document.getElementsByClassName("content");
              for (i = 0; i < content.length; i++) {
                  content[i].style.display = "none";
              }
              for (i = 0; i < links.length; i++) {
                  links[i].className = links[i].className.replace(" active", "");
              }
              document.getElementById(lang).style.display = "block";
              document.getElementById(lang).style.opacity = "1";
              e.currentTarget.className += " active";
          }
      </script>
<!--=============================== delete quesr==========-->
  <script>
  $('.delete').on("click", function (e) {
  e.preventDefault();

  var choice = confirm($(this).attr('data-confirm'));

  if (choice) {
  window.location.href = $(this).attr('href');
  }
  });

  </script>
<!--=========================== selsect approvr levels================-->
  <script>
      // Material Select Initialization
      $(document).ready(function() {
          $('.mdb-select').materialSelect();
      });
  </script>
</body>

</html>
