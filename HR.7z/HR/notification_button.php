

<?php
include 'config/conn.php';
if(isset($_GET['id'])){
  $log_username=$_GET['id'];
}
?>


<div id="notify">
<a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fas fa-bell fa-fw"></i>
    <!-- Counter - Alerts -->
    <?php

    $sql_notif_count="SELECT COUNT(CODE)AS count FROM `system_notification` WHERE `is_enable` = 1 AND `user_name` = '$log_username'";
    $qq_count=mysqli_query($conn,$sql_notif_count);
    $rr_count=mysqli_fetch_assoc($qq_count);
    ?>
    <span class="badge badge-danger badge-counter"><?php if(($rr_count['count'])>0){ echo $rr_count['count']."";} ?></span>
</a>
<!-- Dropdown - Alerts -->

<div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
    <h6 class="dropdown-header">
        Alerts Center
    </h6>
    <?php
        $sql_notif="SELECT * FROM `system_notification` WHERE `is_read` = 0 AND  user_name='$log_username'ORDER BY last_update DESC LIMIT 4";
        $rr=mysqli_query($conn,$sql_notif);
    $rows_count=mysqli_num_rows($rr);
    if($rows_count>0) {
        while ($notification_rr = mysqli_fetch_assoc($rr)) {
            $notify_header = $notification_rr['notification_header'];
            $request_code = $notification_rr['code'];
            $date = $notification_rr['create_date'];
            $request_date = date('F d , y', strtotime($date));
            $icon = $notification_rr['icon'];
            $link_script = $notification_rr['link_script'];

            ?>

            <a class="dropdown-item d-flex align-items-center" href="<?php echo $link_script ?>">
                <div class="mr-3">
                    <div class="icon-circle bg-primary">
                        <i class="<?php echo $icon ?> text-white"></i>
                    </div>
                </div>
                <div>
                    <div class="small text-gray-500"><?php echo $request_date ?></div>
                    <span class="font-weight-bold">A new request in request ID [ <?php echo $request_code ?> ] Aprove From <?php echo $notify_header ?> </span>
                </div>
            </a>

        <?php
        }
        echo '<a class="dropdown-item text-center small text-gray-500" href="notification.php">Show All Alerts</a>';
    }else{
         echo '<span class="dropdown-item text-center small text-gray-500">No any Notification </span>';
    }
    ?>


<!--                <i class="fas fa-donate text-white"></i>-->

</div>
</div>