<?php

//
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);



if(isset($_GET['token'])){
    session_start();
    if($_GET['token']='lo1'){
        session_destroy();
        unset($_SESSION["full_name"]);
    }
}
session_start();
include 'config/conn.php';

if(isset($_POST['login'])){
///////////////// chesk first log /////////////////////////////////
    $user_name=mysqli_real_escape_string($conn, $_POST['U_name']);
    $password=mysqli_real_escape_string($conn, $_POST['password']);
    $h_password=md5($password);
    $sql_log="SELECT * FROM system_users WHERE user_name='$user_name' AND password='$h_password'  ";
    $QQ_log=mysqli_query($conn, $sql_log);
    $rr_log=mysqli_fetch_assoc($QQ_log);
    if(mysqli_num_rows($QQ_log)>0) {
        echo $log_ststus = $rr_log['login_status'];
        echo $log_id = $rr_log['id'];
        $encoded = base64_encode($log_id);
        if ($log_ststus == 1) {


            $sql = "SELECT * FROM system_users WHERE user_name='$user_name' AND password='$h_password' AND is_enable=1 ";
            $QQ = mysqli_query($conn, $sql);
            if (mysqli_num_rows($QQ) > 0) {
                while ($rr = mysqli_fetch_assoc($QQ)) {
                    echo $_SESSION["user_name"] = $rr['user_name'];
                    echo $_SESSION['log_role'] = $rr['role'];
                    echo $_SESSION["full_name"] = $rr['full_name'];
                    echo $_SESSION["log_id"] = $rr['id'];
                    echo $_SESSION["profile_pic"] = $rr['profile_pic'];
                    if (!empty($_POST["remember"])) {
                        setcookie("member_login", $_POST["U_name"], time() + (10 * 365 * 24 * 60 * 60));
                    } else {
                        if (isset($_COOKIE["member_login"])) {
                            setcookie("member_login", "");
                        }
                    }
                    $_SESSION['start'] = time(); // Taking now logged in time.
                    // Ending a session in 30 minutes from the starting time.
                    $_SESSION['expire'] = $_SESSION['start'] + (30 * 60);
                    $rr['is_enable'];
                    //////////////////// first log ////////////////////
                    $id = $rr['id'];
                    $sql_2 = " UPDATE system_users SET login_status=1  WHERE id = '$id'";
                    $rr_q = mysqli_query($conn, $sql_2);


                    if ($rr_q) {
                        header('location:index.php');
                        // echo $_SESSION['full_name'];
                    }
                }
            } else {
                $error = 1;
            }
        } elseif ($log_ststus == 0) {
            echo "asdsad";
            header("location:validation.php?id='.$encoded.'");
        }
    }else{
        $error = 2;
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>HR System - Login</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <!--<link href="css/HR-admin-2.min.css" rel="stylesheet">-->
  <link href="css/HR-admin-2.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
              <div class="col-lg-6">
                <div class="p-5" align="center">
                  <div class="text-center" >
                    <h1 class="h4 text-gray-900 mb-4">Welcome To HR !</h1>
                  </div>
                  <form class="user d-none d-sm-inline-block  mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" name="U_name" value="<?php if(isset($_COOKIE['member_login'])) {echo $_COOKIE['member_login'] ;} ?>" id="exampleInputEmail" required="" aria-describedby="emailHelp" placeholder="Enter User Name...">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" name="password" id="exampleInputPassword" required="" placeholder="Password">
                    </div>
<!--        =================================log error===============================================-->
                      <?php
                      if( isset($error)){
                          ?>
                          <div class="col-lg-12 mb-4" id="Bar">
                              <div class="card bg-danger text-white shadow">
                                  <!--                              <div id="right">-->
                                  <!--                                  <a href="#" onclick="Hide(Bar);">X</a>-->
                                  <!--                              </div>-->
                                  <div class="card-body">
                                      Error
                                      <?php
                                      if($error==1){
                                          echo '<div class="text-white-50 small">You Can not Access</div>';
                                      }elseif($error==2){
                                          echo '<div class="text-white-50 small">Username Or Password Is incorrect</div>';
                                      }
                                      ?>


                                  </div>
                              </div>
                          </div>

                          <?php
                      }
                      ?>


                    <div class="form-group">
                      <div class="custom-control custom-checkbox small">
                        <input type="checkbox"  name="remember" class="custom-control-input" id="customCheck">
                        <label class="custom-control-label" for="customCheck">Remember Me</label>
                      </div>
                    </div>
                      <div class="form-group">
                        <button TYPE="submit" name="login" class="btn btn-primary btn-user btn-block">Login</button>
                          </div>


                  </form>

                  <div class="text-center">
                    <a class="small" href="forgot-password.html">Forgot Password?</a>
                  </div>
                  <!--<div class="text-center">-->
                    <!--<a class="small" href="register.html">Create an Account!</a>-->
                  <!--</div>-->
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
