<?php


class notifications {




    public function notify($AppStatus,$id,$log_user_id){
        include("/../config/conn.php");
        $id;
       $Notify_type=$AppStatus;
        if($Notify_type=='A') {
            $sql_manpower_request = "SELECT * FROM manpower_request WHERE Approve_status='$Notify_type' AND request_id='$id' ";
            $rr_a = mysqli_query($conn, $sql_manpower_request);
            $row__data=mysqli_fetch_assoc($rr_a);
            //=mysqli_fetch_assoc($rr);
            $request_date_time=$row__data['create_date'];
            $request_date = date('F d , y', strtotime( $row__data['create_date']));
            $request_id = $id;
            $code_2 = 'A';
            $notification_header = "New Request";
            $user_arr = $this->Select_username($Notify_type);
             $notification = $this->notification_body($notification_header, $request_date, $request_id);
            //var_dump($user_arr);

        }else{
            $sql_manpower_request="SELECT * FROM manpower_request WHERE Approve_status='$Notify_type' AND id='$id' ";
            $rr=mysqli_query($conn,$sql_manpower_request);
            //echo  $row_count=mysqli_num_rows($rr);

               $row_request_dqta=mysqli_fetch_assoc($rr);
               $request_date_time=$row_request_dqta['create_date'];
                $request_id= $row_request_dqta['request_id'];



        $request_date = date('F d , y', strtotime( $row_request_dqta['create_date']));

        if($Notify_type=='HR-A'){

            $code_2='HR-A';
            $notification_header="HR-Accepted";
            $user_arr=$this->Select_username($Notify_type);
            $notification=$this->notification_body($notification_header,$request_date,$request_id);
            $link="Request_action.php";

        }elseif($Notify_type=='IE-A'){
            $code_2='IE-A';
            $notification_header="IE-Accepted";
            $user_arr=$this->Select_username($Notify_type);
            $notification=$this->notification_body($notification_header,$request_date,$request_id);
            $link="Request_action.php";

        }elseif($Notify_type=='OM-A'){
            $code_2='OM-A';
            $notification_header="OM-Accepted";
            $user_arr=$this->Select_username($Notify_type);
            $notification=$this->notification_body($notification_header,$request_date,$request_id);
            $link="Request_action.php";

        }elseif($Notify_type=='MD-A'){
            $code_2='MD-A';
            $notification_header="MD-Accepted";
            $type="A";
            $user_arr=$this->Select_username($type);
            $notification=$this->notification_body($notification_header,$request_date,$request_id);
            $link="Request_action.php";
            //var_dump($user_arr);
        }
        elseif($Notify_type=='CV_A'){
            $request_id=$id;
            $code_2='CV_A';
            $notification_header="CV-Accepted";
            $type="A";
            $user_arr=$this->Select_username($type);
            $link='#';
            $notification="<a class='dropdown-item d-flex align-items-center' href='#'>
                            <div class='mr-3''>
                                <div class='icon-circle bg-primary'>
                                    <i class='fas fa-info fa-fw text-white'></i>
                                </div>
                            </div>
                            <div>
                                <div class='small text-gray-500'>".$request_date."</div>
                                <span class='font-weight-bold'>A CV Accepted on Request [ ".$request_id." ] By  ". $log_user_id."</span>
                            </div>
                        </a>";
            //var_dump($user_arr);
        }
        }


         $notification_html =mysqli_real_escape_string($conn,$notification);
        foreach($user_arr as $user_name){
             $user_name;
            $sql_info_add = "INSERT INTO system_notification (
                      code,
                      code_2,
                      user_name,
                      link_script,
                      link_param,
                      notification_header,
                      notification,
                      is_enable,
                      is_read,
                      icon,
                      display_date,
                      create_date,
                      last_update
                    )
                    VALUES
                      (
                        '$request_id',
                        '$code_2',
                        '$user_name',
                        '$link',
                        '',
                        '$notification_header',
                        '$notification_html',
                        '1',
                        '0',
                        'fas fa-info fa-fw',
                        '$request_date_time',
                        CURRENT_TIMESTAMP,
                        CURRENT_TIMESTAMP
                      ) ";

            $rr_notify=mysqli_query($conn, $sql_info_add);
            if($rr_notify){
                $success_notify=1;
            }else{
                $success_notify=mysqli_error($conn);
                // mysqli_error($conn);
            }


        }





return $success_notify;

    }

    public function Select_username($Notify_type){
        include("/../config/conn.php");
        $notify_user_array=array();
        if($Notify_type=='A'){
            $sql="SELECT user_name FROM system_users WHERE Approve_level_1='1'";
            $rr=mysqli_query($conn,$sql);
            while($row_notify_user=mysqli_fetch_assoc($rr)){
                $notify_user_array[]=$row_notify_user['user_name'];
            }
        }
        elseif($Notify_type=='HR-A'){
            $sql="SELECT user_name FROM system_users WHERE Approve_level_2='1'";
            $rr=mysqli_query($conn,$sql);
            while($row_notify_user=mysqli_fetch_assoc($rr)){
                $notify_user_array[]=$row_notify_user['user_name'];
            }
        }elseif($Notify_type=='IE-A'){
            $sql="SELECT user_name FROM system_users WHERE Approve_level_3='1'";
            $rr=mysqli_query($conn,$sql);
            while($row_notify_user=mysqli_fetch_assoc($rr)){
                $notify_user_array[]=$row_notify_user['user_name'];
            }
        }elseif($Notify_type=='OM-A'){
            $sql="SELECT user_name FROM system_users WHERE Approve_level_4='1'";
            $rr=mysqli_query($conn,$sql);
            while($row_notify_user=mysqli_fetch_assoc($rr)){
                $notify_user_array[]=$row_notify_user['user_name'];
            }
        }elseif($Notify_type=='MD-A'){
            $sql="SELECT user_name FROM system_users ";
            $rr=mysqli_query($conn,$sql);
            while($row_notify_user=mysqli_fetch_assoc($rr)){
                $notify_user_array[]=$row_notify_user['user_name'];
            }
        }
        return $notify_user_array;
    }



    public function notification_body($notification_header,$request_date,$id){
        $notification="<a class='dropdown-item d-flex align-items-center' href='Request_action.php'>
                            <div class='mr-3''>
                                <div class='icon-circle bg-primary'>
                                    <i class='fas fa-info fa-fw text-white'></i>
                                </div>
                            </div>
                            <div>
                                <div class='small text-gray-500'>".$request_date."</div>
                                <span class='font-weight-bold'>A new request in request ID [ ".$id." ] Aprove From ". $notification_header."</span>
                            </div>
                        </a>";
        return $notification;
    }

    public function notify_interview($id,$log_username){

        include("/../config/conn.php");
        $sql_cv="SELECT * FROM aplicant_cv WHERE id='$id'";
        $qq_cv=mysqli_query($conn,$sql_cv);
        $rr_cv=mysqli_fetch_assoc($qq_cv);
        $request_id =$rr_cv['request_id'];



        $link='';
        $notification_header="Interview Schedule";
        $request_date= date('F d , y', strtotime( date('Y-m-d')));
        $sql="SELECT user_name FROM system_users WHERE role='HROfficer'";
        $rr=mysqli_query($conn,$sql);
        $notify_user_array=array();
        while($row_notify_user=mysqli_fetch_assoc($rr)){
            $notify_user_array[]=$row_notify_user['user_name'];
        }


        $notification="<a class='dropdown-item d-flex align-items-center' href='#'>
                            <div class='mr-3''>
                                <div class='icon-circle bg-primary'>
                                    <i class='fas fa-info fa-fw text-white'></i>
                                </div>
                            </div>
                            <div>
                                <div class='small text-gray-500'>".$request_date."</div>
                                <span class='font-weight-bold'>A new Interview has schedule on[ ".$interview_date." ] at [ ".$interview_time."] By - ". $log_username."</span>
                            </div>
                        </a>";
        $notification_html =mysqli_real_escape_string($conn,$notification);
        foreach($notify_user_array as $user_name){
            $user_name;
        $sql_info_add = "INSERT INTO system_notification (
                      code,
                      code_2,
                      user_name,
                      link_script,
                      link_param,
                      notification_header,
                      notification,
                      is_enable,
                      is_read,
                      icon,
                      display_date,
                      create_date,
                      last_update
                    )
                    VALUES
                      (
                        '$request_id',
                        '',
                        '$user_name',
                        '$link',
                        '',
                        '$notification_header',
                        '$notification_html',
                        '1',
                        '0',
                        'fas fa-info fa-fw',
                        '',
                        CURRENT_TIMESTAMP,
                        CURRENT_TIMESTAMP
                      ) ";

        $rr_notify=mysqli_query($conn, $sql_info_add);
        if($rr_notify){
            $success_notify=1;
        }else{
            $success_notify=mysqli_error($conn);
            // mysqli_error($conn);
        }
        }
        return $success_notify;
    }



    public function  notify_interview_approved($id,$log_username){
        include("/../config/conn.php");
        $sql_cv="SELECT * FROM aplicant_cv WHERE id='$id'";
        $qq_cv=mysqli_query($conn,$sql_cv);
        $rr_cv=mysqli_fetch_assoc($qq_cv);
        $request_id =$rr_cv['request_id'];



        $link='calling_interview.php';
        $notification_header="Interview Schedule Approv";
        $request_date=date('F d , y', strtotime( date('Y-m-d')));
        $sql="SELECT user_name FROM system_users WHERE role='HROfficer'";
        $rr=mysqli_query($conn,$sql);
        $notify_user_array=array();
        while($row_notify_user=mysqli_fetch_assoc($rr)){
            $notify_user_array[]=$row_notify_user['user_name'];
        }


        $notification="<a class='dropdown-item d-flex align-items-center' href='calling_interview.php'>
                            <div class='mr-3''>
                                <div class='icon-circle bg-primary'>
                                    <i class='fas fa-info fa-fw text-white'></i>
                                </div>
                            </div>
                            <div>
                                <div class='small text-gray-500'>".$request_date."</div>
                                <span class='font-weight-bold'> A Scheduled interview has Approve [ ".$request_id." ] By - ". $log_username."</span>
                            </div>
                        </a>";
        $notification_html =mysqli_real_escape_string($conn,$notification);
        foreach($notify_user_array as $user_name){
            $user_name;
            $sql_info_add = "INSERT INTO system_notification (
                      code,
                      code_2,
                      user_name,
                      link_script,
                      link_param,
                      notification_header,
                      notification,
                      is_enable,
                      is_read,
                      icon,
                      display_date,
                      create_date,
                      last_update
                    )
                    VALUES
                      (
                        '$request_id',
                        '',
                        '$user_name',
                        '$link',
                        '',
                        '$notification_header',
                        '$notification_html',
                        '1',
                        '0',
                        'fas fa-info fa-fw',
                        '',
                        CURRENT_TIMESTAMP,
                        CURRENT_TIMESTAMP
                      ) ";

            $rr_notify=mysqli_query($conn, $sql_info_add);
            if($rr_notify){
                $success_notify=1;
            }else{
                $success_notify=mysqli_error($conn);
                // mysqli_error($conn);
            }
        }
        return $success_notify;
    }
}

