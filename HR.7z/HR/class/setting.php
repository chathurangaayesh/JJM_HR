<?php

class setting
{


    public function roleValQyesry($log_username)
    {
        include("/../config/conn.php");
        $sql="SELECT role FROM system_users WHERE user_name='$log_username'";
        $qq=mysqli_query($conn, $sql);
        $rr=mysqli_fetch_assoc($qq);
        return $rr['role'];

    }

}

?>
